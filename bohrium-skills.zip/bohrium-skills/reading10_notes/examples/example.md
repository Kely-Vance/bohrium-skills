# 最小调用示例（示意，非正式案例结果）

输入：`paper.pdf`（示意双栏论文）

```bash
python3 scripts/parse_pdf.py paper.pdf --out parse.json
python3 scripts/notes.py finish --parse parse.json --draft draft.json --out result.json
```

示意 `draft.json`（节选，标注为 EXAMPLE）：

```json
{
  "case_id": "EXAMPLE",
  "paper_card": {
    "research_question": {"text": "如何从多栏 PDF 中稳定重建阅读顺序",
      "quote": "we present a method for multi-column reading order recovery",
      "page": 1, "block_id": "p1.b3"},
    "findings": {"text": "双栏顺序重建精度显著高于逐行抽取",
      "quote": "our method outperforms baseline line-by-line extraction",
      "page": 5, "block_id": "p5.b2"}
  },
  "section_notes": [
    {"section": "1 Introduction", "purpose": "说明研究背景与问题",
     "quote": "…原文短引文…", "page": 1, "block_id": "p1.b5"}
  ],
  "qa": [
    {"question": "主要指标是什么？", "answer": "…",
     "quote": "…", "page": 4, "block_id": "p4.b1"}
  ]
}
```

示意校验结论（节选，标注为 EXAMPLE）：

```json
{ "quotes_checked": 4, "quotes_ok": 3,
  "errors": [ {"reason": "quote_wrong_page", "quote": "our method outperforms…"} ] }
```

> 以上为示例，不代表任何正式测试案例的答案。`quote_wrong_page` 表示该引文在原文存在但被绑到了错误的页码，需回改。
