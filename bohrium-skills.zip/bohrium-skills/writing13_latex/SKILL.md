---
name: latex-build-fix
description: 把 LaTeX 源码编译到通过，并把报错定位到具体文件、行号与根因，静态校验公式/表格/引用/模板，维护编译-修复闭环直到交叉引用收敛，交付可继续编辑的源码与可复现的构建记录。用于需要"LaTeX 写作与编译"的学术写作任务。当输入含 .tex/.bib/模板文件且任务要求"编译通过/改错/迁移模板"时使用。
---

# LaTeX 写作与编译：编译得通 + 定位到根因 + 交得可用 + 复现得了

## 1. 这个 Skill 解决什么问题

把一份有问题的 LaTeX 工程修到**能编译、能复用、能复现**。四个目标：

- **编译得通**：源码在指定模板与发行版下按轮次编译通过；报错定位到**文件、行号、根因**，而不是停在第一条报错。
- **改得对**：公式符号与编号、表格数值与列宽、交叉引用与参考文献、版式与模板必填项，既符合原文意图又符合模板要求。
- **交得可用**：交付**可编辑的 .tex 源码**，不是 PDF、截图或一段编不过的片段。
- **复现得了**：记录 TeX 发行版、宏包、编译命令与轮次，他人能复现同一产物。

本 Skill 是「脚本 + 规则 + 大模型复核」混合体：脚本做**静态校验 + 编译 + 日志解析 + 闭环**，大模型做语义修复（公式/表格内容对不对）。

## 2. 何时使用 / 何时不用

**使用**：任务要求编译 LaTeX、修复编译错误、迁移期刊/会议模板、整理引用。

**不用**：纯写作（引言/方法/润色）、知识图谱、翻译、Nanopub。

## 3. 输入与输出

**输入**：`/input/case.json`（`case_id` + `output_contract`）、`/input/task.md`、`.tex` 主文件 + 子文件 + `.bib` + 模板 `.cls/.sty`。**以实际文件为准，不按标签补造。**

**输出**：`/app/output/result.json`（`case_id` + 编译状态 + 错误修复记录 + 源码路径 + 构建记录 + 人工确认项）；可编辑 `.tex` + 编译产物 PDF 一并放 `/app/output`。

## 4. 工作流程（编译-修复闭环）

### 第 0 步：读输入，识别工程结构
记 `case_id`、`output_contract`；读 `task.md` 明确**模板要求与改动范围**；列出主文件、`\input/\include` 子文件、`.bib`、`.cls/.sty`。别漏子文件。

### 第 1 步：静态校验（编译前先查）
```bash
python3 scripts/latex.py check --tex main.tex --bib refs.bib
```
查：花括号/环境配平、`$` 数学模式、`\label` 重复与 `\ref` 悬空、`\cite` 键是否存在、疑似未定义命令。**先修静态错再编译。**

### 第 2 步：编译
```bash
python3 scripts/latex.py compile --main main.tex --out /app/work --rounds 3
```
脚本自动找发行版（xelatex→pdflatex→lualatex→latex）；**若环境无 TeX 二进制，改用平台 `latex-compiler` 工具编译，再用 `inspect` 读日志**：
```bash
python3 scripts/latex.py inspect --log main.log
```

### 第 3 步：按错误分类修复（不是"停在第一条"）
`inspect`/`compile` 给出**全部**错误的 `kind` + `line` + 根因，逐条对应修：

| 错误 kind | 根因 | 修法 |
|-|-|-|
| `undefined_control_sequence` | 命令拼错 / 缺宏包 | 改拼写，或补 `\usepackage` |
| `missing_dollar` | 数学符号漏 `$` | 补 `$...$` 或 `\(...\)` |
| `missing_file` | `.sty`/图片/子文件缺失 | 补文件或修正路径 |
| `environment_mismatch` | `\begin`/`\end` 不配 | 对齐环境名 |
| `brace_mismatch` | 花括号不配 | 配平括号 |
| `double_superscript` | `x^a^b` | 写成 `x^{ab}` |
| `misplaced_alignment` | `&` 在表格外 | 移入 tabular/align |
| `undefined_reference` | `\ref` 指向不存在的 `\label` | 补 label 或改 ref 名 |
| `undefined_citation` | `\cite` 键不在 `.bib` | 补条目或改键 |

**一次改一处，改完就复编译**；避免"加一个宏包坏另一处"的连锁。

### 第 4 步：复编译直到收敛
```bash
python3 scripts/latex.py compile --main main.tex --out /app/work --rounds 3
python3 scripts/latex.py verify --log /app/work/main.log
```
交叉引用/引用编号需要**多遍编译**才能收敛（`undefined_reference` 在第一遍消失属正常，跑到稳定为止）。`verify` 确认 `success: true` 且无 `undefined_refs`。

### 第 5 步：改得对（语义复核）
- **公式**：符号、上下标、单位正斜体、编号与正文叙述一致；别为"编得过"而改符号含义。
- **表格**：数值、列宽、对齐、合并单元格与原文一致；宽表别用缩放掩盖溢出。
- **引用**：`\cite/\ref` 编号与 `.bib` 条目、正文论断一一对应。
- **模板**：期刊/会议/学位模板的必填项、文件结构、版式约束逐项满足。

### 第 6 步：交得可用 + 复现得了
- 交付**可编辑 .tex + 编译 PDF**；`result.json` 写清 `engine`、宏包、编译命令、轮次、修复记录、未确认项。
- 源码结构清楚（主文件/子文件/导言区组织），别人能接着改。

## 5. 异常与诚实规则

| 情况 | 处置 |
|-|-|
| 缺宏包/字体 | 记录缺失项，标 `needs_install`，别伪造已装 |
| 报错级联 | 修第一个根因后复编译，逐层消 |
| 模板 `.cls` 缺失 | `missing_file` + `cannot_judge`，不自行造模板 |
| 权限不足 / 只读 | 记录，不硬写 |
| 编译超时 | 用 `-halt-on-error` 截断，定位首个致命错误 |

**总原则**：源码与原文是事实依据；交付可编辑源码；未确认的改动明确标注；不伪造编译成功或软件状态。
