---
name: evidence-aligned-translation
description: 把科研论文按段落翻译成可核验的双语对照，术语表全篇锁定同一译名、段落不漏不重、数字/公式/文献编号保真、译文能指回原文。用于需要"文献翻译"的科研阅读任务，强调术语一致性、长文分段、双语对照与译文核验。当输入是论文 PDF/XML 且任务要求"翻译/双语对照"时使用。
---

# 文献翻译：术语锁定 + 段落对齐 + 译文核验

## 1. 这个 Skill 解决什么问题

把论文译成**可核验的双语对照**，而不是一段通顺的大意。四个目标：

- **术语稳**：同一术语在标题、摘要、正文、图注、结论里始终用同一译名；术语表**真正被执行**，不是写在提示里。
- **段落全**：长文跨页、跨栏、跨章节不漏段、不重复、不错位，段号与原文一一对应。
- **关系准**：指代对象、否定与限定、因果与让步、数字单位、公式与文献编号与原文一致。
- **可核验**：每段译文能指回原文，译不准的部分明确标注，不含混。

本 Skill 是「脚本 + 规则 + 大模型复核」混合体：脚本做版面解析、**分段**与**译文审计**（覆盖率、术语锁定、数字保真），大模型负责实际翻译。

## 2. 何时使用 / 何时不用

**使用**：任务要求翻译论文（全文或指定段落区间）、双语对照、术语表驱动翻译。

**不用**：Nanopublication、知识图谱、结构化笔记、写作润色等其它任务。

## 3. 输入与输出

**输入**：`/input/case.json`（`case_id` + `output_contract`）、`/input/task.md`、论文 PDF/XML，可能带**给定术语表**与**指定翻译范围**。**以实际文件为准，不按领域标签补造。**

**输出**：`/app/output/result.json`（`case_id` + 双语对照 `bilingual` + 术语表 + 审计报告 + 需人工确认清单）。

## 4. 工作流程（按顺序）

### 第 0 步：读输入，锁定边界
记 `case_id`、`output_contract`；读 `task.md` 明确**翻译范围**（全文？某几段？图注？）与**给定术语表**；找到材料路径。

### 第 1 步：探测环境 + 解析
```bash
python3 -c "import pymupdf" 2>/dev/null && echo PY_PDF_ENGINE=1 || echo PY_PDF_ENGINE=0
```
- `=1` → `python3 scripts/parse_pdf.py "<PDF>" --out /app/work/parse.json`
- `=0` → 用 `pdf-text-tool` 取全文、`pdf-render-tool` 渲染核对、`ocr-tool` 处理扫描页。

### 第 2 步：建术语表（先锁定，再翻译）
把给定术语表 + 从原文抽的领域术语合成 `/app/work/glossary.json`：
```json
{ "credible interval": "可信区间", "rate constant": "速率常数", "V_max": "V_max" }
```
**一条术语只锁一个译名**；一词多义时按义项分别锁定并在 `change_log` 说明。**术语表是硬约束**，正文/图注/结论必须用同一译名。

### 第 3 步：分段 + 分批翻译（段落全）
```bash
python3 scripts/translate.py batches --parse /app/work/parse.json --max-chars 6000
```
得到按 block 切分的批次（跨页/跨栏的 block 由脚本按顺序排好）。**按批次逐段翻译**，每段保留 `block_id`，写到 `/app/work/translation.json`：
```json
{ "p1.b3": "…译文…", "p1.b4": "…译文…" }
```

**翻译规则（关系准）**：
- **否定/限定不能翻转**："不增加 A、但减少 B" 不能译成"增加 A、但不减少 B"。
- **数字、单位、公式、图表/文献编号**原样保留；公式按原样抄（`$...$` 或编号），不译公式本身。
- 每批翻译**携带已锁定的术语表**，别凭空用别的译名。

### 第 4 步：脚本审计（可核验）
```bash
python3 scripts/translate.py audit --parse /app/work/parse.json \
  --glossary /app/work/glossary.json --translation /app/work/translation.json \
  --out /app/output/result.json
```
脚本核验：**每个原文段落都有译文**（漏段报 `missing_paragraphs`，分母来自原文不是抽到的子集）、**术语锁定是否执行**（`term_not_locked`）、数字是否丢失（告警）。**报错回第 3 步补。**

### 第 5 步：自查
output_contract 全覆盖？段号与原文一一对应？术语表全篇统一？译不准的段落标了"需人工确认"？

## 5. 异常与诚实规则

| 情况 | 处置 |
|-|-|
| 原文段落残缺 / 文字层缺失 | `cannot_judge` 或 OCR 兜底；读不出标 `read_out:false` |
| 公式/表格是图片 | 用 `pdf-render-tool` 渲染后译，标 `source: rendered` |
| 术语一词多义无法确定 | 标 `needs_human_review`，不含混 |
| 翻译范围外内容 | 不译，并在结果里说明范围 |

**总原则**：原文是唯一事实依据；术语锁定硬执行；译不准明确标注；不凭常识改数字或关系。
