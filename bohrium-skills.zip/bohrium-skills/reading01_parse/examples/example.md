# 最小调用示例（示意，非正式案例结果）

> **本文件全部为示例（EXAMPLE）**，用于说明接口与完整调用流程，不冒充任何正式测试案例的答案。

## 1. 输入

一份双栏科研论文 `paper.pdf`（示意：标题 + 作者 + 摘要 + 双栏正文 + 表格 + 编号公式 + 参考文献）。

## 2. 调用方式

```bash
pip install PyMuPDF pdfplumber            # 安装推荐依赖（可选，脚本可无依赖兜底）
python3 scripts/parse_pdf.py paper.pdf --out parse.json
```

## 3. 示意输出（节选）

`parse.json` 的 `meta` 与 `pages[0]` 节选：

```json
{
  "meta": { "engine": "pymupdf", "pages": 3, "scanned_pages": [], "has_text_layer": true },
  "pages": [
    {
      "page": 1, "width": 612, "height": 792,
      "columns": [177.5, 434.0],
      "blocks": [
        { "block_id": "p1.b0", "type": "title", "text": "A Study of Multi-Column Layout Parsing",
          "bbox": [161.6, 82.4, 450.5, 99.6], "column": 1, "max_font_size": 17.2 },
        { "block_id": "p1.b1", "type": "author", "text": "Alice Smith and Bob Jones",
          "bbox": [236.2, 115.4, 375.8, 127.3], "column": 1 },
        { "block_id": "p1.b3", "type": "heading", "text": "1\nIntroduction",
          "bbox": [54.0, 264.9, 167.1, 279.2], "column": 0, "level": 1 }
      ],
      "reading_order_text": "A Study of Multi-Column Layout Parsing\n\nAlice Smith and Bob Jones\n\nAbstract\n\nWe present a method …\n\n1 Introduction\n\nScientific documents …"
    }
  ],
  "sections": [
    { "title": "1 Introduction", "level": 1, "page": 1, "block_id": "p1.b3", "bbox": [54.0, 264.9, 167.1, 279.2] }
  ],
  "formulas": [
    { "page": 1, "number": "(2)",
      "text": "σ=vuutN1X_{i=1}^{N}(x_{i}−x¯)^{2}(2)",
      "spans": [ { "text": "σ", "role": "main", "bbox": [129.3,720.9,135.0,730.9] },
                 { "text": "i=1", "role": "sub", "bbox": [173.0,735.0,185.9,742.0] } ] }
  ]
}
```
> 公式解读：`^{...}` 上标、`_{...}` 下标、`vuut` 是根号绘制碎片、`X` 常是求和号字形；`number` 为公式编号，`spans` 带每个字形的角色与 bbox 供复核。

## 4. Agent 后续

Agent 读取 `parse.json` 后，按 `SKILL.md` 第 3–6 步：核验阅读顺序 → 按 `output_contract` 组装结构化结果 → 为每条关键结论回填 `page + block_id + bbox` → 写 `/app/output/result.json`。
