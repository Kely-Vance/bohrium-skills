# 最小调用示例（示意，非正式案例结果）

```bash
python3 scripts/parse_pdf.py paper.pdf --out parse.json
python3 scripts/translate.py audit --parse parse.json --glossary glossary.json \
  --translation translation.json --out result.json
```

示意 `glossary.json`（标注为 EXAMPLE）：

```json
{ "credible interval": "可信区间", "rate constant": "速率常数" }
```

示意 `translation.json`（节选，标注为 EXAMPLE）：

```json
{ "p1.b3": "……可信区间不同于置信区间……",
  "p1.b4": "……速率常数，如 k、V_max……" }
```

示意审计结论（节选，标注为 EXAMPLE）：

```json
{ "n_source": 25, "n_translated": 25, "errors": [] }
```

> 以上为示例。若出现 `missing_paragraphs`，说明有原文段落没译；`term_not_locked` 说明某术语没按术语表锁定的译名译。
