---
name: nanopub-evidence-workbench
description: 把科研论文的关键结论拆成可独立验证的原子断言（主体—关系—客体 + 条件 + 统计量），每条绑定最小充分证据片段与原文位置，并输出可机器读取的 JSON / TriG。用于需要"Nanopublication、断言抽取、证据溯源"的科研阅读任务，强调断言粒度、证据对齐、来源可追溯。当输入是论文 PDF 且任务要求"拆断言/抽关系/绑证据"时使用。
---

# Nanopublication：拆断言 + 绑证据 + 可追溯

## 1. 这个 Skill 解决什么问题

把论文里的结论变成**一条条可独立判断真假的原子断言**，每条都能回到原文最小证据。四个目标：

- **拆得细**：一段复合结论拆成多条单关系断言，不把整段塞进一个字段。
- **对得上**：每条断言绑定**最小充分证据片段**（一句话/一个结果子句），且原文位置可指出。
- **追得回**：断言、证据、论文、作者、年份、版本、标识符链路完整。
- **读得懂**：导出结构化 JSON + TriG，下游程序能直接解析。

本 Skill 是「脚本 + 规则 + 大模型复核」混合体：脚本做版面解析与**断言校验**（证据真实性、数字绑定、关系受控词表），大模型负责拆解与语义判断。

## 2. 何时使用 / 何时不用

**使用**：任务要求从论文抽取原子断言、Nanopublication、知识单元、证据绑定、来源回溯。

**不用**：结构化笔记（阅读10）、知识图谱（阅读15）、翻译（阅读03）、写作类任务。

## 3. 输入与输出

**输入**：`/input/case.json`（`case_id` + `output_contract`）、`/input/task.md`、论文 PDF。**以实际文件内容为准，不补造。**

**输出**：`/app/output/result.json`（`case_id` + 断言数组 + 校验报告 + TriG + 状态 + 不确定性）。

## 4. 工作流程（按顺序）

### 第 0 步：读输入，锁定边界
读 `case.json` 记 `case_id` 与 `output_contract`；读 `task.md`；找到 PDF 实际路径。

### 第 1 步：探测环境 + 解析
```bash
python3 -c "import pymupdf" 2>/dev/null && echo PY_PDF_ENGINE=1 || echo PY_PDF_ENGINE=0
```
- `=1` → `python3 scripts/parse_pdf.py "<PDF>" --out /app/work/parse.json`
- `=0` → 用 `pdf-text-tool` / `pdf-render-tool` / `ocr-tool` 兜底再手动重建。

**按需取证**：`--page N` / `--block p3.b7` 只拉一块。预算守恒：64 请求 / 900 秒 / 每次约 1.6 万 token，**不要把整张表塞给模型**（分享里的教训：展开整表 → 76 掉到 65）。

### 第 2 步：读 parse.json
用 `blocks[]` 拿段落与 `block_id`；对需要精确数字/行列的地方，用 `--page N` 定位到具体块，再人工核对渲染图（`pdf-render-tool`）。

### 第 3 步：写断言 draft
写 `/app/work/draft.json`：

```json
{
  "case_id": "<来自 case.json>",
  "assertions": [
    {
      "id": "n1",
      "subject": "年龄(存活组)",
      "relation": "compared_with",
      "object": "年龄(死亡组)",
      "conditions": "按6个月后存活与否分组的观察性比较",
      "statistics": {"p": 0.33, "interpretation": "无显著差异"},
      "confidence": "medium",
      "confidence_basis": "p=0.33 来自原文结果句，未见显著性",
      "evidence": {"quote": "There were no statistically significant differences ... (p = 0.33),",
                   "page": 5, "bbox": [315,561,554,635], "block_id": "p5.b2"},
      "publication": {"title": "…", "authors": "…", "year": 2011, "doi": "…"}
    }
  ],
  "uncertainty": [], "change_log": []
}
```

**拆解规则（拆得细）**：
- 一条断言**只写一个可独立验证的关系**。"A increases B and reduces C" 拆成两条；并列/因果/转折都要拆。
- `relation` 用受控词表（`compared_with` / `increases` / `decreases` / `causes` / `associated_with` / `correlates_with` / `predicts` / `no_effect_on` / …）；词表没有的就用最贴近的一个并在 `change_log` 说明。
- 保留**条件和限定**（分组方式、测量单位、置信区间），别把"观察性关联"写成"因果"。

**证据规则（对得上）**：
- `quote` 是**最小充分**的连续原文（结果子句/一句话），不是整段，也不是你的转述。
- `page`/`block_id`/`bbox` 指向**真正包含该引文**的位置。
- 断言里的**每个统计数字**（p 值、均值、样本量）都必须出现在 `quote` 里——防止抄错邻格/另一行（分享里的"全球换成海洋"教训）。

**溯源（追得回）**：`publication` 填全标题/作者/年份/DOI；`id` 稳定可引用。

### 第 4 步：脚本校验 + 导出
```bash
python3 scripts/nanopub.py build --parse /app/work/parse.json \
  --draft /app/work/draft.json --out /app/output/result.json
```
脚本逐条核验：证据是否真在原文该位置、统计数字是否在引文里、关系是否在词表、是否复合关系、置信度有无依据、是否重复断言。**报错的必须回第 3 步改。**

### 第 5 步：自查
output_contract 全覆盖？每条断言能回原文？读不出/证据跨图表/断言找不到支撑的，如实标 `无法判断`，不硬凑。

## 5. 异常与诚实规则

| 情况 | 处置 |
|-|-|
| 断言找不到支撑片段 / 证据跨图表 | 标 `uncertainty`，或降 `confidence` 并写明"证据不足" |
| 复合句拆不出单关系 | 拆成多条，或标 `无法原子化` |
| 加密 PDF / 扫描件 | `cannot_judge` 或 OCR 兜底，读不出标 `read_out:false` |
| 数值在表里但行列不明 | 用 `pdf-render-tool` 核对行列后绑定，标 `source` 为表格行列 |

**总原则**：原论文是唯一事实依据；断言可复核；无法判断的绝不写成事实；置信度必须有依据，不做无凭据的"高置信"。
