# 阅读03｜文献翻译

按段落翻译成双语对照，术语表锁定、覆盖率审计、数字保真。

## 调用方式

```bash
python3 scripts/parse_pdf.py 论文.pdf --out parse.json
python3 scripts/translate.py batches --parse parse.json --max-chars 6000   # 分批
# 模型逐段翻译 -> translation.json { "p1.b3": "译文", ... }
python3 scripts/translate.py audit --parse parse.json --glossary glossary.json \
  --translation translation.json --out result.json   # 审计+组装
```

## 审计规则

| 检查 | 拦截的错误 |
|-|-|
| 每个原文段落都有译文（分母来自原文） | 漏段 |
| 术语表锁定译名是否在对应译文里 | 术语不统一/漏译术语 |
| 数字是否丢失（告警） | 数字/单位抄错 |

## 术语表格式

```json
{ "credible interval": "可信区间", "rate constant": "速率常数" }
```

一条术语只锁一个译名，全篇硬执行。

## 限制

- 数字保真为告警（跨语言数字形式可能合法变化，如 8.74 million → 874 万）。
- 语义正确性（否定/限定/因果方向）由模型负责，脚本只拦覆盖率与术语硬错。
