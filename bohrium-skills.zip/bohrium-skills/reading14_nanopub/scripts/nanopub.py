#!/usr/bin/env python3
"""Deterministic finisher for 阅读14｜Nanopublication.

The Agent writes atomic assertions (subject—relation—object + conditions +
statistics), each bound to a minimal verbatim evidence quote and its
page/block position.  This script does the deterministic checks a weak model
gets wrong:

  * one independently testable relation per assertion (no compound "A and B");
  * evidence quote is a real, contiguous substring of the PDF at the claimed
    page/block;
  * every statistic the assertion relies on actually occurs in that quote
    (number binding — catches copying the neighbour cell / another table row);
  * relation type is in a controlled vocabulary;
  * duplicate assertions are flagged;
  * confidence must have an explicit basis (no self-assessed "high" with no
    supporting quote).

It exports machine-readable JSON and a minimal TriG nanopublication skeleton.
It never invents content: unverifiable evidence is reported, not repaired.

Usage:
  python3 nanopub.py build --parse parse.json --draft draft.json --out result.json
  python3 nanopub.py check --parse parse.json --draft draft.json
"""
import argparse
import json
import re
import sys

RELATION_VOCAB = {
    "compared_with", "causes", "increases", "decreases", "associated_with",
    "correlates_with", "predicts", "inhibits", "activates", "expresses",
    "located_in", "part_of", "has_property", "measured_as", "reports",
    "finds", "no_effect_on", "differs_from", "same_as", "contains",
}


def _norm(s):
    if s is None:
        return ""
    return re.sub(r"\s+", " ", s).strip().lower()


def _numbers(s):
    """Return a set of normalised numeric tokens in a string (for binding)."""
    toks = set()
    for m in re.finditer(r"\d[\d,]*(?:\.\d+)?", s or ""):
        t = m.group(0).replace(",", "")
        toks.add(t)
        try:
            toks.add(str(float(t)))          # 8.74 -> "8.74"
            toks.add(repr(float(t)).rstrip("0").rstrip("."))  # "8.74"
        except ValueError:
            pass
    return toks


def load_parse(path):
    d = json.load(open(path, encoding="utf-8"))
    blocks = []
    page_norm = {}
    block_norm = {}
    for p in d.get("pages", []):
        pno = p.get("page")
        page_norm[pno] = ""
        for b in p.get("blocks", []):
            t = b.get("text", "")
            n = _norm(t)
            blocks.append({"page": pno, "block_id": b.get("block_id", ""),
                           "text": t, "norm": n, "bbox": b.get("bbox")})
            page_norm[pno] += "\n" + t
            block_norm[b.get("block_id", "")] = n
    full = "\n".join(_norm(b["text"]) for b in blocks)
    page_norm = {k: _norm(v) for k, v in page_norm.items()}
    return {"blocks": blocks, "full": full, "page_norm": page_norm,
            "block_norm": block_norm, "meta": d.get("meta", {})}


def check_evidence(parse, ev, stats_text):
    """Validate one evidence object.  stats_text joins the numeric fields."""
    quote = ev.get("quote", "") if isinstance(ev, dict) else ""
    page = ev.get("page") if isinstance(ev, dict) else None
    bid = ev.get("block_id") if isinstance(ev, dict) else None
    q = _norm(quote)
    out = {"quote": quote[:120]}
    if not q:
        out["ok"] = False
        out["reason"] = "empty_evidence"
        return out
    # minimal-sufficiency: one contiguous clause/sentence, not a paragraph/table
    if len(q) > 400:
        out["ok"] = False
        out["reason"] = "evidence_not_minimal"
        return out
    if q not in parse["full"]:
        out["ok"] = False
        out["reason"] = "quote_not_found"
        return out
    if page is not None and q not in parse["page_norm"].get(page, ""):
        out["ok"] = False
        out["reason"] = "quote_wrong_page"
        return out
    if bid and q not in parse["block_norm"].get(bid, ""):
        out["ok"] = False
        out["reason"] = "quote_wrong_block"
        return out
    # number binding: numeric values in the assertion must appear in the quote
    missing = []
    for n in sorted(_numbers(stats_text) - _numbers(quote)):
        missing.append(n)
    if missing:
        out["ok"] = False
        out["reason"] = "stat_not_in_evidence"
        out["missing_numbers"] = missing[:8]
        return out
    out["ok"] = True
    out["reason"] = "verified"
    return out


def validate_assertion(parse, a, idx):
    errs = []
    for f in ("subject", "relation", "object"):
        if not (a.get(f) or "").strip():
            errs.append(f"missing_{f}")
    rel = (a.get("relation") or "").strip().lower()
    if rel and rel not in RELATION_VOCAB:
        errs.append(f"relation_not_in_vocab:{rel}")
    # one relation per assertion: reject compound "X and Y"
    if rel and (" and " in rel or ";" in rel or "、" in rel):
        errs.append("compound_relation")

    ev = a.get("evidence") or {}
    stats_text = " ".join(str(v) for k, v in (a.get("statistics") or {}).items()
                          if isinstance(v, (int, float, str)))
    stats_text += " " + str(a.get("conditions") or "")
    evr = check_evidence(parse, ev, stats_text)
    a["_evidence"] = evr
    if not evr.get("ok"):
        errs.append(evr.get("reason"))

    conf = (a.get("confidence") or "").strip()
    if conf in ("high", "medium") and not (a.get("confidence_basis") or "").strip():
        errs.append("confidence_without_basis")
    if conf not in ("high", "medium", "low", "unknown", ""):
        errs.append("invalid_confidence")

    # provenance completeness (追得回)
    pub = a.get("publication") or {}
    for f in ("title", "authors", "year", "doi"):
        if not str(pub.get(f) or "").strip():
            errs.append(f"missing_publication_{f}")
    return errs


def build_triG(assertions):
    lines = [
        "@prefix ex: <http://example.org/nanopub/> .",
        "@prefix prov: <http://www.w3.org/ns/prov#> .",
        "",
    ]
    for a in assertions:
        aid = a.get("id", "n")
        s = a.get("subject", "").replace(" ", "_")
        r = a.get("relation", "").replace(" ", "_")
        o = a.get("object", "").replace(" ", "_")
        pub = a.get("publication") or {}
        doi = pub.get("doi", "")
        year = pub.get("year", "")
        lines.append(f"# {pub.get('title','')[:80]} ({year}) {doi}")
        lines.append(f"ex:{aid} {{ ex:{s} ex:{r} ex:{o} . }}")
        lines.append(f"ex:{aid} prov:wasDerivedFrom ex:{doi} ." if doi else f"ex:{aid} prov:generatedAtTime \"{year}\" .")
    return "\n".join(lines)


def build(args):
    parse = load_parse(args.parse)
    draft = json.load(open(args.draft, encoding="utf-8"))
    assertions = draft.get("assertions", [])
    report = {"checked": len(assertions), "ok": 0, "errors": [], "warnings": []}
    seen = set()
    subj_rel = {}
    for i, a in enumerate(assertions):
        errs = validate_assertion(parse, a, i)
        a["_errors"] = errs
        if not errs:
            report["ok"] += 1
        else:
            report["errors"].append({"index": i, "id": a.get("id"),
                                     "errors": errs,
                                     "quote": (a.get("evidence") or {}).get("quote", "")[:100]})
        key = (_norm(a.get("subject")), _norm(a.get("relation")), _norm(a.get("object")))
        if key in seen:
            report["errors"].append({"index": i, "id": a.get("id"),
                                     "errors": ["duplicate_assertion"]})
        seen.add(key)
        # same subject+relation but different object -> possible contradiction
        sr = (_norm(a.get("subject")), _norm(a.get("relation")))
        if sr in subj_rel and subj_rel[sr] != _norm(a.get("object")):
            report["warnings"].append({"index": i, "id": a.get("id"),
                                       "reason": "potential_contradiction",
                                       "detail": f"{a.get('subject')} {a.get('relation')} "
                                                 f"{subj_rel[sr] or '?'} vs {a.get('object')}"})
        subj_rel[sr] = _norm(a.get("object"))

    status = "success" if not report["errors"] else "partial"
    result = {
        "case_id": draft.get("case_id"),
        "status": status,
        "status_reason": "" if status == "success" else f"{len(report['errors'])} assertion errors",
        "assertions": assertions,
        "validation": report,
        "trig": build_triG(assertions),
        "meta": {"engine": parse["meta"].get("engine")},
    }
    out = json.dumps(result, ensure_ascii=False, indent=2)
    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(out)
        print(f"wrote {args.out} (status={status}, assertions {report['ok']}/{report['checked']} ok)",
              file=sys.stderr)
    else:
        print(out)
    return 0


def check(args):
    parse = load_parse(args.parse)
    draft = json.load(open(args.draft, encoding="utf-8"))
    report = {"checked": len(draft.get("assertions", [])), "errors": []}
    for i, a in enumerate(draft.get("assertions", [])):
        errs = validate_assertion(parse, a, i)
        if errs:
            report["errors"].append({"index": i, "errors": errs})
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("build", "check"):
        s = sub.add_parser(name)
        s.add_argument("--parse", required=True)
        s.add_argument("--draft", required=True)
        if name == "build":
            s.add_argument("--out")
    args = ap.parse_args(argv)
    return build(args) if args.cmd == "build" else check(args)


if __name__ == "__main__":
    raise SystemExit(main())
