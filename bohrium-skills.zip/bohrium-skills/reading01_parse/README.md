# 科研论文 PDF 结构化解析 Skill

围绕「文献文档解析」构建的可被 Agent 调用的 Skill：把科研 PDF 解析成结构化、可溯源到原文页码与区块的结果，重点解决**多栏阅读顺序、复杂表格、章节层级、公式/特殊字符保真、扫描版 OCR** 五类问题。

## 目录结构

```
submission/
├── SKILL.md                 # Skill 本体（Agent 读取的指令）
├── README.md                # 本文件：使用与方法说明
├── scripts/
│   └── parse_pdf.py         # 确定性版面解析脚本
└── examples/
    └── example.md           # 最小调用示例（示意，非正式案例答案）
```

## 安装与依赖

脚本按「最优优先」自动降级选择解析引擎，**零必需依赖也能跑**（pypdf 兜底）：

| 引擎 | 能力 | 是否必需 |
|-|-|-|
| PyMuPDF (`fitz`) | 字形级坐标、字体/字号、图片位置 | 推荐，`pip install PyMuPDF` |
| pdfplumber | 表格检测、文字位置 | 可选，`pip install pdfplumber` |
| pypdf | 纯文本（无坐标） | 兜底，通常已内置 |

安装推荐依赖：
```bash
pip install PyMuPDF pdfplumber
```

## 调用方式（完整流程）

```bash
# 1) 解析 PDF，输出结构化 JSON（紧凑索引，不含逐字形坐标）
python3 scripts/parse_pdf.py 论文.pdf --out parse.json

# 2) 查看元信息（引擎、页数、扫描页）
python3 -c "import json;print(json.load(open('parse.json'))['meta'])"

# 3) 按需取证：只拉某一页 / 某张表 / 某条公式，避免反复读全文
python3 scripts/parse_pdf.py 论文.pdf --page 3
python3 scripts/parse_pdf.py 论文.pdf --table 1
python3 scripts/parse_pdf.py 论文.pdf --formula 2
python3 scripts/parse_pdf.py 论文.pdf --block p3.b7
```

之后由 Agent 读取 `parse.json`（或按需 `--page/--table/--formula` 取证），按 `SKILL.md` 第 3–7 步核验阅读顺序、按价值顺序组装结果并回填证据定位。

## 输入输出

**输入**：一个 PDF 文件路径。

**输出**（`parse.json`）：
```json
{
  "meta":        { "engine":"pymupdf", "pages":15, "scanned_pages":[], "has_text_layer":true },
  "pages":       [ { "page":1, "width":612, "height":792, "columns":[177,434],
                     "blocks":[ {"block_id":"p1.b3","type":"heading","text":"1 Introduction",
                                 "bbox":[54,265,167,279],"column":0,"max_font_size":14.3} ],
                     "reading_order_text":"…", "header_signature":null, "footer_signature":null } ],
  "sections":    [ {"title":"1 Introduction","level":1,"page":1,"block_id":"p1.b3","bbox":[...]} ],
  "tables":      [ {"page":1,"bbox":[...],"markdown":"| … |"} ],
  "formulas":    [ {"page":1,"number":"(2)","text":"σ=vuutN1X_{i=1}^{N}(x_{i}−x¯)^{2}(2)",
                    "spans":[{"text":"σ","role":"main","bbox":[...]}, ...]} ],
  "figures":     [ {"page":1,"bbox":[...],"xref":12} ],
  "references":  [ {"text":"[1] …","page":15,"block_id":"p15.b2","bbox":[...]} ],
  "diagnostics": { "warnings":[] }
}
```

## 关键方法

1. **栏目检测**（`detect_columns`）：只用正文文本块，取左右边界跨度；跨度 > 页宽 60% 且中部存在竖版沟槽（gutter）时判为双栏，返回左右栏中心。标题、作者、公式、页眉页脚均被排除，不会被居中元素带偏。
2. **阅读顺序重建**（`reconstruct_reading_order`）：跨越元素（标题/作者/超宽块）按 y 排在最前，然后每栏自上而下（LaTeX/IEEE 双栏惯例）。
3. **块分类**（`classify_blocks`）：最大字号块 = 标题；标题正下方短行 = 作者；`[n]` 开头 = 参考文献；编号/命名/加粗放大短行 = 章节标题（层级由编号点数推断）；纯数字不判为标题（避免页码误判）。
4. **章节层级**：从「3.2.1」式编号的点数推断 level（3→L1，3.2→L2，3.2.1→L3）。
5. **页眉页脚**：跨页在相同边缘重复的文本记为 signature，供 Agent 剔除。
6. **扫描页检测**：页文本量 < 40 字符判为疑似扫描页，在 `scanned_pages` 中标注，交由 OCR 或如实标注「读不出」。
7. **公式检测与重建**（`_detect_formulas`）：以右缘的公式编号 `(n)` 为锚点，把同一纵向带内、编号左侧的字形合并成**一个**公式块；按字号与基线把字形分为主行 / 上标 / 下标，输出 `^{...}` / `_{...}` 标记，并保留每个字形的 bbox 供复核。行内无编号公式用「居中数学字符富集」启发式兜底。

## 使用增益（朴素抽取 vs 本 Skill）

| 维度 | 朴素文本抽取（baseline） | 本 Skill |
|-|-|-|
| 双栏顺序 | 按 PDF 内部顺序串成一行，左右栏交错 | 按栏重建阅读顺序 |
| 公式 | 碎片成多个散块（`σ =`、`v\nu\u\nt 1`、`i=1`…） | 合并为一个块，标出上下标 |
| 证据定位 | 无 | 每条结论带 `page + block_id + bbox` |
| 章节 | 无层级 | 按编号推断 L1/L2/L3 |
| 扫描件 | 静默空文本 | 显式标 `scanned_pages` + OCR 流程 |

> 说明：以上对照基于本仓库自带样例与一篇真实 arXiv 论文的实测；正式评分由平台在 3 个固定案例上对比「基础 Agent / 加载本 Skill 的 Agent」得出。

## 适用场景与限制

**适用**：有文字层的科研论文 PDF（单栏/双栏/多栏），含常规表格、编号公式、参考文献。

**限制（如实声明）**：
- 表格检测依赖 PyMuPDF `find_tables`（需 onnxruntime）或 pdfplumber；对**无框线表、图片型表**可能漏检，需 Agent 依 bbox 手动重建。
- 公式已能合并碎片并标上下标，但**不解析数学含义**：根号 `√` 常以绘制碎片 `vuut` 出现、求和号 `∑` 常以 `X` 出现、分式上下位置需 Agent 依 bbox 复核；大型分式/矩阵/大型算子仍需 Agent 重建。
- 扫描件需外部 OCR；脚本本身不含 OCR 引擎，只负责标注。
- 分栏带式（报纸式）排版、超宽跨页续表、竖排/手写体不在首版覆盖范围。

## 失败处理

| 失败 | 脚本行为 | Agent 处置 |
|-|-|-|
| PDF 加密 | 可能提取为空 | 状态 `cannot_judge`，说明加密 |
| 无文字层扫描件 | `scanned_pages` 列出 | OCR 或标注「读不出」 |
| 无任何 PDF 库 | 输出 `{"error":"no PDF library available"}` | 记录并上报，不编造 |
| 文件不存在 | 退出码 2，stderr 报错 | 检查路径 |

## 自查方法（提交前逐项过一遍）

1. `python3 scripts/parse_pdf.py 论文.pdf` 能无报错跑完，`diagnostics.warnings` 可控。
2. 双栏论文 `pages[i].columns` 非空、单栏为空。
3. `reading_order_text` 顺序与原文一致，页眉页脚不在正文中。
4. 每条关键结论都能给出 `page + block_id + bbox`。
5. 读不出的部分已标注，未写成事实。
