---
name: evidence-led-literature-notes
description: 把科研论文变成字段化、可溯源、可复用的结构化笔记：论文卡片（研究问题/数据/方法/发现/局限）、按原章节的笔记、问答，每条关键论断都带原文短引文与页码/区块定位。用于需要"文献总结/结构化笔记"的科研阅读任务，强调章节对齐、要素留存、来源回链。当输入是论文 PDF/XML 且任务要求"总结、笔记、提取"而非直接写作时使用。
---

# 文献总结与结构化笔记

## 1. 这个 Skill 解决什么问题

把一篇论文变成**可复核、可比较、可继续加工**的笔记，而不是一段压缩后的通读摘要。四个目标：

- **对得上**：笔记骨架跟着论文**自己**的章节和论证顺序走，不套通用摘要模板。
- **留得住**：研究问题、数据、方法条件、主要发现、局限（尤其让结论成立的**前提条件**）都记下来。
- **找得回**：每条关键笔记带**原文短引文 + 页码 + block_id**，能回到原文具体位置。
- **用得上**：字段统一，同领域多篇论文能并排比较、可检索、可复用。

本 Skill 是「脚本 + 规则 + 大模型复核」混合体：脚本做版面解析与**证据校验**（引文是否真的在原文该位置），大模型负责语义判断与笔记撰写。

## 2. 何时使用 / 何时不用

**使用**：输入是论文 PDF/XML，任务要求结构化笔记、论文卡片、章节摘要、知识点清单、问答。

**不用**：翻译（阅读03）、Nanopublication（阅读14）、知识图谱（阅读15）、写作润色等是别的 Skill；或输入已是干净 Markdown 且不要求溯源。

## 3. 输入与输出

**输入**（运行时以 `/input/case.json` 与 `task.md` 为准）：
- `/input/case.json`：`case_id` 与 **`output_contract`**（本案例要求输出的全部字段，必须覆盖）。
- `/input/task.md`：具体任务说明。
- 案例材料：一份论文 PDF（或材料目录）。**以实际文件内容为准，不按文件名/领域标签补造。**

**输出**（写到 `/app/output/`）：`result.json`（含 `case_id` + output_contract 全部字段 + 证据 + 状态 + 不确定性）。

## 4. 工作流程（按顺序）

### 第 0 步：读输入，锁定边界
读 `/input/case.json` 记下 `case_id` 与 `output_contract` 每个字段；读 `task.md` 明确要什么；找到材料 PDF 实际路径。

### 第 1 步：探测环境 + 解析
先探测，再选路（评测环境只保证声明的 Harbor 工具，PyMuPDF 未必在）：

```bash
python3 -c "import pymupdf" 2>/dev/null && echo PY_PDF_ENGINE=1 || echo PY_PDF_ENGINE=0
```

- `PY_PDF_ENGINE=1` → `python3 scripts/parse_pdf.py "<PDF>" --out /app/work/parse.json`
- `PY_PDF_ENGINE=0` → 用声明的 `pdf-text-tool` 取全文、`pdf-render-tool` 渲染核对、`ocr-tool` 处理扫描页，再按第 3 步规则手动重建。

**按需取证**（别反复读全文）：`--page N` / `--block p3.b7` 只拉一小块。预算守恒：64 次请求、900 秒、每次约 1.6 万 token，只读你需要的证据。

### 第 2 步：读 parse.json，建立章节骨架
用 `sections[]` 作为笔记骨架；`blocks[]` 提供段落级文本与 `block_id`；`reading_order_text` 是顺序初值，**逐页核对**（双栏、跨页续接、真/假图注、上标丢失）。

### 第 3 步：写笔记 draft（先骨架、后逐项补）
写 `/app/work/draft.json`，结构如下（每条都带 `quote` + `page` + `block_id`）：

```json
{
  "case_id": "<来自 case.json>",
  "paper_card": {
    "research_question": {"text": "…", "quote": "原文短引文", "page": 1, "block_id": "p1.b3"},
    "sample":          {"text": "…", "quote": "…", "page": 2, "block_id": "p2.b5"},
    "design":          {"text": "…", "quote": "…", "page": 2, "block_id": "p2.b7"},
    "findings":        {"text": "…", "quote": "…", "page": 5, "block_id": "p5.b2"},
    "limitations":     {"text": "…", "quote": "…", "page": 8, "block_id": "p8.b4"}
  },
  "section_notes": [
    {"section": "1 Introduction", "purpose": "…", "key_points": ["…"],
     "quote": "…", "page": 1, "block_id": "p1.b5"}
  ],
  "qa": [
    {"question": "…", "answer": "…", "quote": "…", "page": 3, "block_id": "p3.b2"}
  ],
  "uncertainty": [], "change_log": []
}
```

**写作顺序（按价值落盘，防超时交白卷）**：① 先写 `paper_card` 五个字段并保存 → ② 再逐节写 `section_notes`，每节写完保存 → ③ 最后写 `qa`。超时砍掉的是最后一步，别让正文和卡片被砍。

**关键规则**：
- `quote` 必须是从原文**逐字抄**的短引文（一句话/一个结果子句），不是你的转述。
- 每条 note 的 `page`/`block_id` 要指向**真正包含该引文**的位置（不是"这个数在原文某处出现过"）。
- **脚本字段只读**：`sections`、阅读顺序、`block_id` 来自脚本，不要自己重算覆盖；你若觉得脚本错了，把差异写进 `change_log`，不悄悄改。
- **原文矛盾要保留**：论文自己前后矛盾（如方法写毫秒、表里用秒），两条都记并标出矛盾，**不要替论文裁决**。

### 第 4 步：脚本校验 + 组装（收尾交给脚本）
```bash
python3 scripts/notes.py finish --parse /app/work/parse.json \
  --draft /app/work/draft.json --out /app/output/result.json
```
脚本逐条核验：引文是否真的出现在原文、是否在你声称的页/块里、必需字段是否非空、章节是否重复。**报 `quote_wrong_page` / `quote_not_found` 的必须回第 3 步改**，直到无错或确属"原文未报告"并写明。

### 第 5 步：自查（交付前）
1. output_contract 字段**全部**覆盖？2. 每条结论能回到原文 `quote + page + block_id`？3. 读不出的（未报告/无法判断/材料冲突）如实标注，没写成事实？4. 有没有重复段落/模板空壳？

## 5. 异常与诚实规则

| 情况 | 处置 |
|-|-|
| 加密 PDF / 无文字层扫描件 | 状态 `cannot_judge` 或 OCR 兜底；读不出就标 `read_out:false`，不补造 |
| 引文对不上原文 | 脚本已报错，改引文或如实标 `无法定位` |
| 材料缺失 / 原文自相矛盾 | 状态 `partial`，列出缺失项、保留矛盾 |
| 超长论文 | 按 `sections[]` 切分逐节处理，别一次塞全文 |

**总原则**：实际输入文件和原论文是唯一事实依据；关键结论必须可复核；无法判断的绝不写成事实。
