#!/usr/bin/env python3
"""Deterministic finisher for 阅读15｜文献知识图谱构建.

The Agent writes entities, relations, cross-paper alignment decisions and
queries.  This script does the deterministic checks a weak model gets wrong:

  * every entity/relation evidence quote is a real, contiguous substring of
    the PDF at the claimed page/block;
  * entity and relation types are in a controlled vocabulary;
  * same-name entities MUST have an explicit alignment decision
    (merge / keep_separate / unresolved) — name is never treated as identity;
  * relation subject/object must reference existing entity ids;
  * at least 3 queries are supplied.

It exports a machine-readable graph (nodes/edges JSON) plus a DOT file, and
reports merge/conflict handling.  It never invents content.

Usage:
  python3 kg.py build --parse parse.json --draft draft.json --out result.json
  python3 kg.py check --parse parse.json --draft draft.json
"""
import argparse
import json
import re
import sys

ENTITY_TYPES = {"researcher", "material", "method", "task", "metric", "conclusion"}
RELATION_TYPES = {"uses", "compares", "outperforms", "supports", "contradicts",
                  "produces", "measures", "correlates_with"}
ALIGN_DECISIONS = {"merge", "keep_separate", "unresolved"}


def _norm(s):
    if s is None:
        return ""
    return re.sub(r"\s+", " ", s).strip().lower()


def load_parse(path):
    d = json.load(open(path, encoding="utf-8"))
    page_norm, block_norm = {}, {}
    for p in d.get("pages", []):
        pno = p.get("page")
        page_norm[pno] = ""
        for b in p.get("blocks", []):
            t = b.get("text", "")
            n = _norm(t)
            page_norm[pno] += "\n" + t
            block_norm[b.get("block_id", "")] = n
    full = "\n".join(_norm(b["text"]) for p in d["pages"] for b in p.get("blocks", []))
    page_norm = {k: _norm(v) for k, v in page_norm.items()}
    return {"full": full, "page_norm": page_norm, "block_norm": block_norm,
            "meta": d.get("meta", {})}


def check_evidence(parse, ev):
    quote = (ev or {}).get("quote", "")
    page = (ev or {}).get("page")
    bid = (ev or {}).get("block_id")
    q = _norm(quote)
    if not q:
        return {"ok": False, "reason": "empty_evidence"}
    if q not in parse["full"]:
        return {"ok": False, "reason": "quote_not_found"}
    if page is not None and q not in parse["page_norm"].get(page, ""):
        return {"ok": False, "reason": "quote_wrong_page"}
    if bid and q not in parse["block_norm"].get(bid, ""):
        return {"ok": False, "reason": "quote_wrong_block"}
    return {"ok": True, "reason": "verified"}


def build(args):
    parse = load_parse(args.parse)
    draft = json.load(open(args.draft, encoding="utf-8"))
    entities = draft.get("entities", [])
    relations = draft.get("relations", [])
    alignment = draft.get("alignment", [])
    queries = draft.get("queries", [])

    report = {"errors": [], "warnings": [], "n_entities": len(entities),
              "n_relations": len(relations), "n_queries": len(queries)}
    eids = set()

    # entities
    for i, e in enumerate(entities):
        errs = []
        if not (e.get("name") or "").strip():
            errs.append("missing_name")
        if (e.get("type") or "") not in ENTITY_TYPES:
            errs.append(f"type_not_in_vocab:{e.get('type')}")
        evr = check_evidence(parse, e.get("evidence"))
        e["_evidence"] = evr
        if not evr.get("ok"):
            errs.append(evr["reason"])
        if errs:
            report["errors"].append({"kind": "entity", "index": i, "id": e.get("id"), "errors": errs})
        if e.get("id"):
            eids.add(e.get("id"))

    # relations
    for i, r in enumerate(relations):
        errs = []
        if r.get("subject") not in eids:
            errs.append("subject_not_entity")
        if r.get("object") not in eids:
            errs.append("object_not_entity")
        if (r.get("type") or "") not in RELATION_TYPES:
            errs.append(f"type_not_in_vocab:{r.get('type')}")
        evr = check_evidence(parse, r.get("evidence"))
        r["_evidence"] = evr
        if not evr.get("ok"):
            errs.append(evr["reason"])
        if errs:
            report["errors"].append({"kind": "relation", "index": i, "id": r.get("id"), "errors": errs})

    # same-name entities must have an explicit alignment decision
    by_name = {}
    for e in entities:
        by_name.setdefault(_norm(e.get("name")), []).append(e.get("id"))
    for name, ids in by_name.items():
        if len(ids) > 1:
            decided = any(set(ids) <= set(a.get("entities", []))
                          for a in alignment if a.get("entities"))
            if not decided:
                report["warnings"].append({
                    "reason": "same_name_no_alignment", "name": name, "ids": ids})

    # alignment decisions must be valid + reasoned
    for i, a in enumerate(alignment):
        errs = []
        if (a.get("decision") or "") not in ALIGN_DECISIONS:
            errs.append(f"decision_not_in_vocab:{a.get('decision')}")
        if not a.get("entities"):
            errs.append("missing_entities")
        if not (a.get("reason") or "").strip():
            errs.append("missing_reason")
        if errs:
            report["errors"].append({"kind": "alignment", "index": i, "errors": errs})

    # queries
    if len(queries) < 3:
        report["errors"].append({"kind": "queries", "errors": [f"need_at_least_3_queries (have {len(queries)})"]})

    status = "success" if not report["errors"] else "partial"
    graph = {
        "nodes": [{"id": e.get("id"), "label": e.get("name"), "type": e.get("type"),
                   "paper": e.get("paper")} for e in entities],
        "edges": [{"source": r.get("subject"), "target": r.get("object"),
                   "type": r.get("type"), "conditions": r.get("conditions")} for r in relations],
    }
    result = {
        "case_id": draft.get("case_id"),
        "status": status,
        "status_reason": "" if status == "success" else f"{len(report['errors'])} errors",
        "graph": graph,
        "alignment": alignment,
        "queries": queries,
        "validation": report,
        "dot": to_dot(graph),
    }
    out = json.dumps(result, ensure_ascii=False, indent=2)
    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(out)
        print(f"wrote {args.out} (status={status}, {len(entities)} entities, "
              f"{len(relations)} relations)", file=sys.stderr)
    else:
        print(out)
    return 0


def to_dot(graph):
    lines = ["digraph G {"]
    for n in graph["nodes"]:
        lines.append(f'  "{n["id"]}" [label="{n["label"]}"];')
    for e in graph["edges"]:
        lines.append(f'  "{e["source"]}" -> "{e["target"]}" [label="{e["type"]}"];')
    lines.append("}")
    return "\n".join(lines)


def check(args):
    # reuse the same validation, printing the full result (validation included)
    return build(argparse.Namespace(parse=args.parse, draft=args.draft, out=None))


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("build", "check"):
        s = sub.add_parser(name)
        s.add_argument("--parse", required=True)
        s.add_argument("--draft", required=True)
        if name == "build":
            s.add_argument("--out")
    args = ap.parse_args(argv)
    return build(args) if args.cmd == "build" else check(args)


if __name__ == "__main__":
    raise SystemExit(main())
