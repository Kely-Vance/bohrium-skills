# 最小调用示例（示意，非正式案例结果）

```bash
python3 scripts/parse_pdf.py paper.pdf --out parse.json
python3 scripts/nanopub.py build --parse parse.json --draft draft.json --out result.json
```

示意 `draft.json` 断言（节选，标注为 EXAMPLE）：

```json
{
  "case_id": "EXAMPLE",
  "assertions": [
    {
      "id": "n1",
      "subject": "age(survivors)",
      "relation": "compared_with",
      "object": "age(non-survivors)",
      "conditions": "observational comparison grouped by 6-month survival",
      "statistics": {"p": 0.33, "interpretation": "no significant difference"},
      "confidence": "medium",
      "confidence_basis": "p=0.33 stated in original result sentence",
      "evidence": {
        "quote": "There were no statistically significant differences ... in terms of age (p = 0.33),",
        "page": 5, "bbox": [315, 561, 554, 635], "block_id": "p5.b2"
      },
      "publication": {"title": "…", "authors": "…", "year": 2011, "doi": "…"}
    }
  ]
}
```

示意校验结论（节选，标注为 EXAMPLE）：

```json
{ "checked": 1, "ok": 1, "errors": [] }
```

> 以上为示例，不代表任何正式测试案例的答案。若出现 `stat_not_in_evidence`，说明断言里的数字不在证据引文中，需回改（防止抄错行列）。
