# 阅读14｜Nanopublication

把论文结论拆成**可独立验证的原子断言**，每条绑定最小充分证据 + 原文位置，导出机器可读的 JSON / TriG。

## 调用方式

```bash
python3 scripts/parse_pdf.py 论文.pdf --out parse.json           # 版面解析
python3 scripts/nanopub.py build --parse parse.json --draft draft.json --out result.json  # 校验+导出
python3 scripts/nanopub.py check --parse parse.json --draft draft.json                    # 只看校验报告
```

## 断言字段

`subject` / `relation` / `object` / `conditions` / `statistics` / `confidence` + `confidence_basis` / `evidence`（`quote`+`page`+`bbox`+`block_id`）/ `publication`。

## 校验规则（拦弱模型易犯的错）

| 检查 | 拦截的错误 |
|-|-|
| 证据引文是否真在原文、且在声称的页/块 | 编造引文、绑错位置 |
| 证据是否**最小充分**（>400 字符判过长） | 塞一整段/整表 |
| 断言里的统计数字是否出现在引文里 | 抄邻格、抄同表另一行（"全球→海洋"） |
| 关系是否在受控词表、是否复合 | "increases and decreases" 未拆分 |
| 置信度是否有依据 | 无凭据的 "high" |
| 出处元数据（标题/作者/年份/DOI）是否齐全 | 来源缺失 |
| 断言是否重复 / 是否互相矛盾 | 同名重复、同主体同关系但客体相反 |

## 导出

`result.json` 含 `assertions`（含 `_evidence`/`_errors` 校验标记）+ `trig`（含出处注释的最小 TriG）+ `validation` 报告（含 `warnings` 矛盾提示）。

## 限制

- 数字绑定是"断言数值必须出现在引文中"的集合比对；**行列归属**仍建议用 `pdf-render-tool` 对表格做最终复核。
- 语义判断（关系方向、因果 vs 相关）由模型负责，脚本只拦硬错；TriG 为最小骨架，非完整 Nanopub provenance 图。
