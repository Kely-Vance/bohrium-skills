# 最小调用示例（示意，非正式案例结果）

```bash
python3 scripts/latex.py check --tex main.tex --bib refs.bib
python3 scripts/latex.py compile --main main.tex --out work/ --rounds 3
```

示意 `check` 输出（节选，标注为 EXAMPLE）：

```json
{ "errors": [ {"type": "math", "detail": "odd number of unescaped $ (1)"} ],
  "warnings": [ {"type": "ref", "detail": "\\ref to undefined label sec:methods"} ] }
```

示意 `compile` 摘要（节选，标注为 EXAMPLE）：

```json
{ "engine": "/usr/bin/pdflatex", "success": true,
  "summary": {"rounds_used": 2, "undefined_refs": []} }
```

> 以上为示例。`success: true` 且 `undefined_refs` 为空表示编译通过、交叉引用已收敛。
