# 写作13｜LaTeX 写作与编译

编译-定位-修复-复编译的确定性闭环；报错定位到文件/行号/根因，交付可编辑源码与可复现记录。

## 调用方式

```bash
python3 scripts/latex.py check   --tex main.tex --bib refs.bib   # 编译前静态校验
python3 scripts/latex.py compile --main main.tex --out work/ --rounds 3  # 编译闭环
python3 scripts/latex.py inspect --log work/main.log             # 读日志（环境无 TeX 时用）
python3 scripts/latex.py verify  --log work/main.log             # 确认收敛
```

## 静态校验

花括号/环境配平、`$` 数学模式、`\label` 重复与 `\ref` 悬空、`\cite` 键存在性、疑似未定义命令。

## 错误分类

| kind | 根因 | 修法 |
|-|-|-|
| `undefined_control_sequence` | 命令拼错/缺宏包 | 改拼写或补 `\usepackage` |
| `missing_dollar` | 数学符号漏 `$` | 补 `$...$` |
| `missing_file` | 缺 `.sty`/图片/子文件 | 补文件或改路径 |
| `environment_mismatch` | `\begin`/`\end` 不配 | 对齐环境名 |
| `brace_mismatch` / `double_superscript` / `misplaced_alignment` | 语法 | 配平/合并/移入表格 |
| `undefined_reference` / `undefined_citation` | `\ref`/`\cite` 悬空 | 补 label/条目或改键 |

## 限制

- 脚本**不自动改 .tex**，只报告；语义修复（公式/表格内容对不对）由模型负责。
- 交叉引用收敛依赖多遍编译，第一遍的 `undefined_reference` 属正常。
- 静态"未定义命令"是启发式，可能有假阳性；以编译日志为准。
