# 阅读10｜文献总结与结构化笔记

把科研论文变成**字段化、可溯源、可复用**的结构化笔记。核心是「脚本做版面解析 + 证据校验，模型做语义判断」。

## 依赖

- `PyMuPDF`（首选）、`pdfplumber`、`pypdf` 任一即可；都没有时用评测环境声明的 `pdf-text-tool`/`pdf-render-tool`/`ocr-tool` 兜底。

## 调用方式

```bash
# 1) 版面解析（含章节、段落块、阅读顺序、证据定位）
python3 scripts/parse_pdf.py 论文.pdf --out parse.json

# 2) 按需取证（避免反复读全文）
python3 scripts/parse_pdf.py 论文.pdf --page 3 --block p3.b7

# 3) 模型写 draft.json（论文卡片 + 章节笔记 + 问答，每条带 quote/page/block_id）

# 4) 脚本校验引文与位置，组装 result.json
python3 scripts/notes.py finish --parse parse.json --draft draft.json --out result.json

# 5) 只看校验报告
python3 scripts/notes.py check --parse parse.json --draft draft.json
```

## 输出结构

`result.json`：`case_id` + `status` + 笔记正文（`result`）+ `validation`（每条引文的核验结论：`verified` / `quote_not_found` / `quote_wrong_page` / `quote_wrong_block`）。

## 关键方法

- **章节对齐**：笔记骨架取自脚本 `sections[]`，不套通用摘要模板。
- **证据校验**：`notes.py` 把每条 `quote` 做空白归一化后在原文全文/该页/该块做子串匹配，并强制"声称的 page/block_id 必须真包含该引文"——拦住"数字在原文某处出现过"这类错绑。
- **位置必填**：每条笔记必须有 `page` + `block_id`（缺了报 `missing_position`）。
- **数字绑定**：笔记正文里的数字必须出现在引文里，否则告警 `note_numbers_not_in_quote`（拦"0.90 抄成 0.88"）。
- **重复模板检测**：同一段笔记正文复制多遍报 `duplicate_note_text`。
- **章节覆盖**：论文 `sections[]` 中未被任何笔记覆盖的章节告警 `section_uncovered`。
- **收尾交给脚本**：模型只写小份 draft，脚本做校验 + 组装 + 状态，超时也有可交付的半成品。

## 限制

- 引文校验是**文本子串匹配**，OCR 或字符集差异可能导致误报；`quote_wrong_*` 需人工复核。
- "引文是否真的支持笔记内容"目前只做**数字重叠**这种词面检查，语义层面（引文讲的是不是同一件事）仍由模型负责，脚本只拦硬错。
