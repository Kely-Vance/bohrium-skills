#!/usr/bin/env python3
"""Deterministic finisher for 阅读10｜文献总结与结构化笔记.

The Agent writes a small notes draft (paper card + section notes + QA, each
carrying a short verbatim quote and its page/block anchor).  This script then
does the deterministic part a weak model gets wrong:

  * verify every quote actually appears in the parsed PDF text;
  * verify the quote is at the page/block the Agent claimed (position binding,
    not mere "the number exists somewhere");
  * verify required paper-card fields are non-empty;
  * verify section notes follow the paper's real sections (no template drift);
  * flag duplicates, empty shells and unverifiable quotes.

It never invents content: a quote that cannot be matched is reported, and the
final result keeps the original text plus an honest evidence status.

Usage:
  python3 notes.py finish --parse parse.json --draft draft.json --out result.json
  python3 notes.py check  --parse parse.json --draft draft.json
"""
import argparse
import json
import re
import sys


def _norm(s):
    """Whitespace-normalised, lowercased text for substring matching."""
    if s is None:
        return ""
    return re.sub(r"\s+", " ", s).strip().lower()


def _numbers(s):
    """Return a set of normalised numeric tokens in a string."""
    toks = set()
    for m in re.finditer(r"\d[\d,]*(?:\.\d+)?", s or ""):
        t = m.group(0).replace(",", "")
        toks.add(t)
        try:
            toks.add(repr(float(t)).rstrip("0").rstrip("."))
        except ValueError:
            pass
    return toks


def load_parse(path):
    d = json.load(open(path, encoding="utf-8"))
    pages = d.get("pages", [])
    # full-text index + per-page and per-block indexes
    blocks = []
    page_text = {}
    block_text = {}
    for p in pages:
        pno = p.get("page")
        pblocks = p.get("blocks", [])
        page_text[pno] = ""
        for b in pblocks:
            t = b.get("text", "")
            bid = b.get("block_id", "")
            n = _norm(t)
            blocks.append({
                "page": pno, "block_id": bid, "text": t, "norm": n,
                "bbox": b.get("bbox"),
            })
            page_text[pno] += "\n" + t
            block_text[bid] = n
    full = "\n".join(_norm(b["text"]) for b in blocks)
    page_norm = {k: _norm(v) for k, v in page_text.items()}
    sections = d.get("sections", []) or []
    return {"blocks": blocks, "full": full, "page_norm": page_norm,
            "block_norm": block_text, "sections": sections,
            "meta": d.get("meta", {})}


def find_quote(parse, quote, page=None, block_id=None):
    """Return an evidence verdict for one quote."""
    q = _norm(quote)
    if not q:
        return {"ok": False, "reason": "empty_quote", "match": False,
                "page_match": None, "block_match": None}
    full_match = q in parse["full"]
    page_match = None
    block_match = None
    if page is not None:
        page_match = q in parse["page_norm"].get(page, "")
    if block_id:
        block_match = q in parse["block_norm"].get(block_id, "")
    # a quote must at least appear somewhere in the paper
    if not full_match:
        return {"ok": False, "reason": "quote_not_found", "match": False,
                "page_match": page_match, "block_match": block_match}
    # position binding: if the Agent claimed a page/block, the quote must be there
    if page is not None and page_match is False:
        return {"ok": False, "reason": "quote_wrong_page", "match": True,
                "page_match": page_match, "block_match": block_match}
    if block_id and block_match is False:
        return {"ok": False, "reason": "quote_wrong_block", "match": True,
                "page_match": page_match, "block_match": block_match}
    return {"ok": True, "reason": "verified", "match": True,
            "page_match": page_match, "block_match": block_match}


def validate_draft(parse, draft):
    """Walk the draft, validate every quote, and collect a report."""
    report = {"quotes_checked": 0, "quotes_ok": 0,
              "errors": [], "missing_required": [], "warnings": []}
    seen_texts = {}

    def walk(obj, path):
        if isinstance(obj, dict):
            if "quote" in obj:
                report["quotes_checked"] += 1
                v = find_quote(parse, obj.get("quote"),
                               obj.get("page"), obj.get("block_id"))
                obj["_evidence"] = v
                if v["ok"]:
                    report["quotes_ok"] += 1
                else:
                    report["errors"].append({
                        "path": path, "reason": v["reason"],
                        "quote": obj.get("quote", "")[:120],
                    })
                # position binding is mandatory for "找得回"
                if obj.get("quote") and not (obj.get("page") and obj.get("block_id")):
                    report["errors"].append({
                        "path": path, "reason": "missing_position",
                        "quote": obj.get("quote", "")[:120],
                    })
                # numeric claims in the note must be supported by the quote
                note_nums = _numbers(str(obj.get("text") or ""))
                quote_nums = _numbers(str(obj.get("quote") or ""))
                unsupported = sorted(note_nums - quote_nums)
                if note_nums and unsupported:
                    report["warnings"].append({
                        "path": path, "reason": "note_numbers_not_in_quote",
                        "numbers": unsupported[:8],
                    })
                # duplicate template detection (same note text copied)
                tkey = _norm(str(obj.get("text") or ""))
                if len(tkey) > 8:
                    if tkey in seen_texts:
                        report["errors"].append({
                            "path": path, "reason": "duplicate_note_text",
                            "quote": (obj.get("text") or "")[:120],
                        })
                    seen_texts[tkey] = path
            for k, v2 in obj.items():
                if k == "_evidence":
                    continue
                walk(v2, f"{path}.{k}")
        elif isinstance(obj, list):
            for i, v2 in enumerate(obj):
                walk(v2, f"{path}[{i}]")

    walk(draft, "$")

    # required paper-card fields (score: 留得住)
    pc = draft.get("paper_card") or {}
    for field in ("research_question", "sample", "design", "findings", "limitations"):
        v = pc.get(field)
        if v is None or (isinstance(v, dict) and not (v.get("text") or v.get("quote"))):
            report["missing_required"].append(f"paper_card.{field}")

    # section alignment: notes should follow the paper's real sections (对得上)
    sections_seen = []
    for sn in draft.get("section_notes", []):
        name = sn.get("section") or sn.get("title") or ""
        if name in sections_seen:
            report["errors"].append({"path": "section_notes", "reason": "duplicate_section", "quote": name})
        sections_seen.append(name)
    # coverage: flag paper sections not covered by any note
    paper_sections = [(s.get("title") or "").strip() for s in parse["sections"]]
    covered = {_norm(x) for x in sections_seen}
    for ps in paper_sections:
        if ps and not any(ps.lower()[:20] in c for c in covered):
            report["warnings"].append({"path": "section_notes",
                                       "reason": "section_uncovered", "quote": ps})

    return report


def finish(args):
    parse = load_parse(args.parse)
    draft = json.load(open(args.draft, encoding="utf-8"))
    report = validate_draft(parse, draft)

    status = "success" if (report["errors"] == [] and not report["missing_required"]) else "partial"
    if report["quotes_checked"] and report["quotes_ok"] == 0:
        status = "partial"

    result = {
        "case_id": draft.get("case_id"),
        "status": status,
        "status_reason": ("" if status == "success"
                          else f"{len(report['errors'])} evidence errors, "
                               f"{len(report['missing_required'])} missing required fields"),
        "result": draft,
        "validation": report,
        "meta": {"engine": parse["meta"].get("engine"),
                 "sections_found": len(parse["sections"])},
    }
    out = json.dumps(result, ensure_ascii=False, indent=2)
    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(out)
        print(f"wrote {args.out} (status={status}, "
              f"quotes {report['quotes_ok']}/{report['quotes_checked']} verified)",
              file=sys.stderr)
    else:
        print(out)
    return 0


def check(args):
    parse = load_parse(args.parse)
    draft = json.load(open(args.draft, encoding="utf-8"))
    report = validate_draft(parse, draft)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("finish", "check"):
        s = sub.add_parser(name)
        s.add_argument("--parse", required=True)
        s.add_argument("--draft", required=True)
        if name == "finish":
            s.add_argument("--out")
    args = ap.parse_args(argv)
    return finish(args) if args.cmd == "finish" else check(args)


if __name__ == "__main__":
    raise SystemExit(main())
