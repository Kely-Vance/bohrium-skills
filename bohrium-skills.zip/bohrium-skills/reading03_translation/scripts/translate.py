#!/usr/bin/env python3
"""Deterministic finisher for 阅读03｜文献翻译.

The Agent translates each source paragraph (block) and locks one translation
per glossary term.  This script does the deterministic checks a weak model
gets wrong:

  * coverage: every source paragraph must have a translation (denominator
    comes from the source document itself, not from what the extractor found);
  * term consistency: every glossary term that appears in a source paragraph
    must show up with its locked translation in that paragraph's target;
  * number/citation preservation: numbers, citation markers and formula slots
    present in the source are reported if missing from the target (warning —
    cross-language number forms can legitimately change).

It assembles the bilingual paragraph alignment and an audit report.  It never
invents a translation.

Usage:
  python3 translate.py audit --parse parse.json --glossary glossary.json \
      --translation translation.json --out result.json
  python3 translate.py batches --parse parse.json --max-chars 6000
"""
import argparse
import json
import re
import sys


def _norm(s):
    if s is None:
        return ""
    return re.sub(r"\s+", " ", s).strip().lower()


def _numbers(s):
    toks = set()
    for m in re.finditer(r"\d[\d,]*(?:\.\d+)?", s or ""):
        t = m.group(0).replace(",", "")
        toks.add(t)
    return toks


def load_source(path):
    d = json.load(open(path, encoding="utf-8"))
    blocks = {}
    order = []
    for p in d.get("pages", []):
        for b in p.get("blocks", []):
            bid = b.get("block_id", "")
            if bid:
                blocks[bid] = {"text": b.get("text", ""), "page": p.get("page"),
                               "bbox": b.get("bbox")}
                order.append(bid)
    return blocks, order, d.get("meta", {})


def audit(args):
    blocks, order, meta = load_source(args.parse)
    glossary = json.load(open(args.glossary, encoding="utf-8"))
    if isinstance(glossary, list):  # accept list of {term, translation}
        glossary = {g.get("term", ""): g.get("translation", "") for g in glossary}
    translation = json.load(open(args.translation, encoding="utf-8"))
    if isinstance(translation, list):  # accept list of {block_id, target}
        translation = {t.get("block_id", ""): t.get("target", "") for t in translation}

    report = {"errors": [], "warnings": [], "n_source": len(blocks),
              "n_translated": len(translation), "term_checks": 0}

    # 1) coverage — denominator is the source document itself
    missing = [bid for bid in order if _norm(translation.get(bid, "")).strip() == ""]
    if missing:
        report["errors"].append({"reason": "missing_paragraphs", "block_ids": missing[:20],
                                 "count": len(missing)})

    # 2) term consistency — locked translation must appear where the term appears
    for term, locked in glossary.items():
        t_norm, l_norm = _norm(term), _norm(locked)
        if not t_norm or not l_norm:
            continue
        for bid in order:
            src = blocks[bid]["text"]
            tgt = translation.get(bid, "")
            if t_norm in _norm(src) and l_norm not in _norm(tgt):
                report["term_checks"] += 1
                report["errors"].append({"reason": "term_not_locked", "term": term,
                                         "locked": locked, "block_id": bid})

    # 3) number preservation (warning — cross-language forms may differ)
    for bid in order:
        src_nums = _numbers(blocks[bid]["text"])
        tgt_nums = _numbers(translation.get(bid, ""))
        lost = sorted(src_nums - tgt_nums)
        if src_nums and lost:
            report["warnings"].append({"reason": "numbers_not_in_target",
                                       "block_id": bid, "numbers": lost[:8]})

    status = "success" if not report["errors"] else "partial"
    result = {
        "case_id": None,
        "status": status,
        "status_reason": "" if status == "success" else f"{len(report['errors'])} errors",
        "bilingual": [{"block_id": bid, "page": blocks[bid]["page"],
                       "source": blocks[bid]["text"],
                       "target": translation.get(bid, "")} for bid in order],
        "glossary": glossary,
        "validation": report,
        "meta": {"engine": meta.get("engine")},
    }
    out = json.dumps(result, ensure_ascii=False, indent=2)
    if args.out:
        with open(args.out, "w", encoding="utf-8") as f:
            f.write(out)
        print(f"wrote {args.out} (status={status}, coverage {report['n_translated']}/{report['n_source']})",
              file=sys.stderr)
    else:
        print(out)
    return 0


def batches(args):
    blocks, order, _ = load_source(args.parse)
    maxc = args.max_chars
    batches, cur, cur_len = [], [], 0
    for bid in order:
        ln = len(blocks[bid]["text"])
        if cur and cur_len + ln > maxc:
            batches.append(cur)
            cur, cur_len = [], 0
        cur.append(bid)
        cur_len += ln
    if cur:
        batches.append(cur)
    out = [{"batch": i + 1, "block_ids": b,
            "chars": sum(len(blocks[x]["text"]) for x in b)} for i, b in enumerate(batches)]
    print(json.dumps(out, ensure_ascii=False, indent=2))
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    sub = ap.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("audit")
    a.add_argument("--parse", required=True)
    a.add_argument("--glossary", required=True)
    a.add_argument("--translation", required=True)
    a.add_argument("--out")
    b = sub.add_parser("batches")
    b.add_argument("--parse", required=True)
    b.add_argument("--max-chars", type=int, default=6000)
    args = ap.parse_args(argv)
    return audit(args) if args.cmd == "audit" else batches(args)


if __name__ == "__main__":
    raise SystemExit(main())
