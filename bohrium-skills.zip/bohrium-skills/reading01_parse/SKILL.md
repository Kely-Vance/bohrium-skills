---
name: research-pdf-parsing
description: 把科研论文 PDF 解析成结构化、可逐字溯源到原文页码与区块的结果。用于需要「文档解析」的科研阅读任务：多栏阅读顺序修正、表格结构还原、章节层级识别、公式与特殊字符保真、扫描版 OCR。适合 PDF 解析、文献抽取、问答取证等需要把关键结论指回原文证据的场景。当输入是 PDF 且任务要求「解析/提取/核验」而非直接写作时使用。
---

# 科研论文 PDF 结构化解析

## 1. 这个 Skill 解决什么问题

把一份科研 PDF 变成**可复核的结构化结果**，而不是一段「看起来像全文」的文本。四个目标：

- **提得全**：正文、图题、脚注、参考文献逐字提取，页眉页脚不混入正文。
- **排得对**：双栏/多栏按原版面顺序输出，不串栏、不错行。
- **拆得清**：章节层级、表格行列、公式上下标与希腊字母还原成可继续处理的结构。
- **核得回**：每段文字、每张表、每个公式都能指回原文页码与区块；读不出的如实标注，不靠猜补齐。

本 Skill 是「脚本 + 规则 + 大模型复核」的混合体：脚本做确定性的版面分析，大模型（你）负责语义判断、顺序修正与最终结构化。

## 2. 何时使用 / 何时不用

**使用**：输入是 PDF（或 PDF 转出的材料），任务要求提取正文、表格、公式、章节、图表位置，并给出证据定位。

**不用**：任务要求翻译、总结、写作、知识图谱等（那些是别的 Skill）；或者输入本身已是干净的纯文本/Markdown。

## 3. 输入与输出

**输入**（运行时由评测环境提供，路径以 `/input/case.json` 与 `task.md` 为准）：
- `/input/case.json`：案例元信息，含 `case_id` 与 **`output_contract`**（本案例要求的输出字段，必须全部覆盖）。
- `/input/task.md`：本案例的具体任务说明。
- 案例材料：一份科研 PDF（或材料目录）。**以实际文件内容为准，不要依据文件名或领域标签补造数据。**

**输出**（写到 `/app/output/`）：
- `/app/output/result.json`：主结果，含 `case_id` + `output_contract` 全部字段 + 证据定位 + 运行状态 + 不确定性。
- 其他可编辑产物（Markdown 表格、结构化 JSON 等）也放 `/app/output/`；Office/PPT/图类产物需附真实渲染的 PDF/PNG 预览。

## 4. 工作流程（务必按顺序执行）

### 第 0 步：读输入，锁定任务边界
1. 读 `/input/case.json`，记录 `case_id` 与 `output_contract` 的每个字段名。
2. 读 `/input/task.md`，明确「要解析出什么、按什么格式、证据要到什么粒度」。
3. 找到材料 PDF 的**实际路径**。若 case.json 给的是目录，先列出目录找到 PDF。

### 第 1 步：探测环境，选解析路径（关键）
评测环境是一张固定的 Docker 镜像，**只保证题面 `resources` 里声明的工具可用**：`pdf-text-tool`（取文字）、`pdf-render-tool`（渲染页）、`ocr-tool`（OCR）、`scientific-python`（Python 环境）。**PyMuPDF / pdfplumber / pypdf 不在声明列表里，不能假定已装。**

先探测，再选路：

```bash
python3 -c "import pymupdf" 2>/dev/null && echo PY_PDF_ENGINE=1 || echo PY_PDF_ENGINE=0
```

- **`PY_PDF_ENGINE=1`（有 Python PDF 库）** → 跑本 Skill 脚本（版面级提取质量最高）：
  ```bash
  python3 scripts/parse_pdf.py "<PDF路径>" --out /app/work/parse.json
  ```
- **`PY_PDF_ENGINE=0`（没有 Python PDF 库）** → 用声明的 Harbor 工具兜底，**不要停**：
  1. 先用 `pdf-text-tool` 取全文（拿到页码 + 段落文本）；
  2. 用 `pdf-render-tool` 把每页渲染成 PNG（用于核对栏位、表格、公式字形）；
  3. 有扫描页时用 `ocr-tool` 识别渲染图；
  4. 按本 Skill 第 3–7 步的规则**手动重建阅读顺序、表格行列、公式上下标**，证据定位写「页码 + 渲染图坐标」。

> 两条路都走不通时才按第 5 节如实报 `partial`/`cannot_judge`，绝不假装解析出来了。

**按需取证（不要反复读全文）**：走脚本路时，需要某页/某表/某公式的细节，用 `inspect` 只拉那一小块：

```bash
python3 scripts/parse_pdf.py "<PDF路径>" --page 3      # 只看第 3 页的块+顺序+该页表格/公式
python3 scripts/parse_pdf.py "<PDF路径>" --table 1     # 只看第 1 张表（行列 Markdown）
python3 scripts/parse_pdf.py "<PDF路径>" --formula 2   # 只看第 2 条公式（含上下标字形）
python3 scripts/parse_pdf.py "<PDF路径>" --block p3.b7 # 只看某个块
```

> 原则（预算守恒）：评测 Agent 只有 64 次请求、900 秒、每次约 1.6 万 token。脚本/工具已把确定性工作做掉，**你只读你需要的那份证据**；多读一段、多翻一轮，留给答题的预算就少一分。

### 第 2 步：读 parse.json，理解版面
`parse.json` 关键字段：

| 字段 | 含义 |
|-|-|
| `meta` | 引擎、页数、`scanned_pages`（无文字层的页）、`has_text_layer` |
| `pages[i].columns` | 该页栏目中心 x 坐标；`[]` = 单栏 |
| `pages[i].blocks[]` | 文本块，每个含 `block_id`(如 `p3.b7`)、`type`(title/author/heading/text/reference)、`text`、`bbox`、`column`、字号 |
| `pages[i].reading_order_text` | 脚本重建的阅读顺序（多栏已按栏重排） |
| `sections[]` | 章节标题、层级、页码、block_id |
| `tables[]` / `figures[]` / `references[]` | 表格、图表、参考文献 |
| `formulas[]` | 显示公式（已把碎片合并为一个块）：`text` 用 `^{...}` 表示上标、`_{...}` 表示下标，`number` 是公式编号，`spans[]` 带每个字形的主/上/下标角色与 bbox |

`block_id` 是证据锚点：最终结果里每条结论都应引用 `block_id` 或页码+bbox。

### 第 3 步：核对与修正阅读顺序（关键，别照抄脚本）
脚本的 `reading_order_text` 是**初值**，你要对照原 PDF 逐页核验：

1. **栏目**：确认 `columns` 判断正确（单栏/双栏）。若脚本判错（如窄栏误判、跨页续表），手动纠正。
2. **顺序**：LaTeX/IEEE 双栏是「左栏从上到下读完 → 右栏从上到下」；若遇到「分栏带式」排版，按 y 坐标逐带从左到右。
3. **跨栏/跨页**：标题或大表可能跨栏，注意不要把它当成某一栏的内容。
4. **页眉页脚**：把 `header_signature` / `footer_signature` 及页码从正文里剔除。

### 第 4 步：提取与结构化（对照 output_contract）
按 task.md 和 output_contract 要求，从 `blocks` 组装出最终结构：

- **正文/段落**：按修正后的阅读顺序拼接；每个段落标注 `page` + `block_id`。
- **章节**：用 `sections[]`，注意把「1 / Introduction」这类被换行拆开的编号与标题合并回「1 Introduction」。
- **表格**：脚本给出 `tables[]`（含 Markdown 与行列）；若脚本漏检（无框线表、图片型表），用 bbox 手动重建，并标注 `source`。
- **公式**：用 `formulas[]`（已把碎片合并、标出上下标）。解读约定：`^{...}` 上标、`_{...}` 下标、`(n)` 是公式编号；字形 `vuut` 是 PDF 里根号 `√` 的绘制碎片，`X` 常是求和号 `∑` 的字形。核对后再转成可读形式，标出公式编号与页码；拿不准的如实标注，不硬猜。若脚本漏检（行内公式、无编号公式），按 bbox 从 blocks 里手动挑出。
- **图表**：从 `figures[]` 拿位置，题注（caption）通常紧跟其后。
- **参考文献**：从 `references[]` 拿，注意被换行拆开的条目要合并回一条。

### 第 5 步：证据与边界（写进 result.json）
对每一条**关键结论**，写入：
- `source`：页码 + `block_id` + bbox（能复核）。
- `uncertainty`：未报告、无法判断、材料冲突、OCR 不确定的项，明确写「无法判断/未报告」，**不写成事实**。

### 第 6 步：写 result.json（按价值落盘）并自查
**先写最值钱的部分，再补其余；写一点、保存一点。** 超时砍掉的总是流程最后一步，所以：

1. **先落盘**：`full_text`/正文、章节结构、表格、公式、参考文献 —— 这些是「提得全、拆得清」的主体，先写进 `result.json` 并保存。
2. **再逐组补**：题目问的问题、每条 `answer`/`evidence` 一组一组写，**每组写完立刻保存**，再写下一组。
3. **最后**才写锦上添花的部分（元数据、审校清单等）。若超时，丢掉的是这些，不是正文和答案。

`result.json` 至少包含：
```json
{
  "case_id": "<来自 case.json>",
  "status": "success | partial | cannot_judge | refused",
  "status_reason": "异常原因或可人工接管位置",
  "...output_contract 的全部字段...": "...",
  "evidence": { "...": {"page": 3, "block_id": "p3.b7", "bbox": [..]} },
  "uncertainty": ["..."],
  "change_log": ["..."]
}
```
写完自查：output_contract 字段是否**全部**覆盖？每条结论能否回到原文？读不出的有没有如实标注？

### 第 7 步：交付前五查（防「自我感觉良好」的错）

1. **完整性对照外部清单**（分母来自原文，不是脚本自己抽到的）：标题、作者、摘要、正文全部章节、**每张图及其题注**、**每张表及其表题**、公式、脚注、参考文献、附录/补充材料——逐项过一遍，漏了哪项单独列出。不要用「脚本抽到了 215 段 → 报 215/215=100%」这种自报口径，分母要数原文里实际有多少。
2. **脚本字段只读**：`columns`、`sections`、公式上下标、表格行列、`reading_order_text` 这些**脚本已算出的确定性字段，不要重算、不要覆盖**。你若觉得脚本错了，把「脚本值 vs 你看到的值 + 证据 bbox」写进 `change_log`，而不是悄悄改掉（两个写入者必有一个出错，脚本的确定性规则通常比临时查询可靠）。
3. **数值绑对位置**：检查「0.90 这个数在原文出现过」**不够**，要检查「它出现在哪一页哪一列哪一行」。抄错邻格、把「全球」写成「海洋」同表另一行，这类错只有绑定 `page + 行列坐标` 才能拦住。
4. **真图注/假图注**：真图注常以 `Fig. N |` 或 `Figure N:` 开头且整段是题注；正文里一句「Figure 4a contains…」开头、字号和正文一样的是**正文，不是图注**。上标别丢（坐标轴 `10⁰…10⁴` 抽出来可能是 `100 101 102 103 104`）。
5. **跨栏/跨页阅读顺序**：图注可能分在两栏、上一页最后半句可能接下一页左栏开头；核对时把这两处单独查一遍。

## 5. 异常与诚实规则（务必遵守）

| 情况 | 处置 |
|-|-|
| 加密 PDF | 状态写 `cannot_judge`，说明「加密无法读取」，不要硬猜 |
| 扫描件/无文字层 | 用 OCR 工具（若可用）或标注该页为 `scanned`、内容不确定，宁可标注「读不出」也不补造 |
| 图片型表格 / 乱码字体 | 标注 `source` 与 `uncertainty`，说明解析方式与可信度 |
| 页码错乱 / 跨页续表 | 记录实际页码，注明「续表」 |
| 材料缺失 | 状态写 `partial`，列出缺失项，不编造缺失的软件状态或数据 |

### 5.1 扫描件 OCR 流程（`meta.scanned_pages` 非空时执行）

对 `scanned_pages` 里的每一页，按顺序：

1. **渲染**：用 `pdf-render-tool`（或 PyMuPDF）把该页渲染成 200–300 DPI 的 PNG，逐页保存到 `/app/work/`。
2. **OCR**：对每张 PNG 调 `ocr-tool`（若环境有），得到文字与坐标；**把 OCR 结果存到 `/app/work/ocr_pN.json`**。
3. **后处理校验**：OCR 出来的公式、数字、希腊字母最容易错（`0/O`、`l/1`、`σ/6`、`∑/Σ`），逐条和渲染图比对；不确定的写入 `uncertainty`。
4. **合并**：OCR 文字与原文 `blocks` 合并，证据定位写「页码 + OCR 行号/区块」，并在 `source` 里标注 `ocr`。
5. **兜底**：若 `ocr-tool` 不可用或该页模糊不清，状态写 `partial`、该页标 `read_out: false`，**明确写「无文字层且 OCR 不可用，未能解析」**，绝不假装读出来了。

**总原则**：实际输入文件和原论文是唯一事实依据；关键结论必须可复核；无法判断的绝不写成事实。

## 6. 最小调用示例（示意，非正式案例结果）

输入：`paper.pdf`（示意双栏论文）
```bash
python3 scripts/parse_pdf.py paper.pdf --out parse.json
```
示意输出（节选，标注为 EXAMPLE）：
```json
{ "page": 1, "columns": [177.5, 434.0],
  "blocks": [ {"block_id":"p1.b3","type":"heading","text":"1 Introduction","bbox":[54,265,167,279],"column":0} ] }
```
> 以上为示例，不代表任何正式测试案例的答案。
