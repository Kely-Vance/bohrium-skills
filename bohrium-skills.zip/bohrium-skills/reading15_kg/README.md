# 阅读15｜文献知识图谱构建

从论文抽取实体与关系、绑定证据、显式处理跨篇对齐，导出可查询图谱（JSON + DOT）。

## 调用方式

```bash
python3 scripts/parse_pdf.py 论文.pdf --out parse.json           # 版面解析
python3 scripts/kg.py build --parse parse.json --draft draft.json --out result.json  # 校验+导出
```

## 校验规则

| 检查 | 拦截的错误 |
|-|-|
| 实体/关系证据是否真在原文、在声称的页/块 | 编造证据、绑错位置 |
| 实体/关系类型是否在受控词表 | 自造类型 |
| 关系 subject/object 是否指向已声明实体 | 悬空边 |
| 同名实体是否有显式对齐决策（merge/keep_separate/unresolved） | 同名误并（名字≠身份） |
| 是否 ≥3 个查询 | 查询不足 |

## 导出

`result.json` 含 `graph`（nodes/edges）、`alignment`（合并决定）、`queries`、`validation`、`dot`（Graphviz 格式）。

## 限制

- 实体/关系语义（是否真的相关、关系方向）由模型负责，脚本只拦硬错。
- 同名对齐决策仍需模型判断，脚本只强制"必须显式决策"，不替模型决定 merge 还是 separate。
