---
name: evidence-literature-kg
description: 从一篇或多篇论文抽取实体与关系、绑定原文证据、显式处理跨篇对齐，并构建可查询、可导出的知识图谱（JSON + DOT）。用于需要"文献知识图谱构建"的科研阅读任务，强调实体真实、关系有据、同名不误并、节点可回原文。当输入是论文 PDF 且任务要求"抽实体/连关系/构图/查询"时使用。
---

# 文献知识图谱构建：抽实体 + 连关系 + 可追溯

## 1. 这个 Skill 解决什么问题

把论文变成**带证据的节点与边**，能回答查询、能回到原文。四个目标：

- **抽得准**：实体是论文里真实出现的科研对象（研究者/材料/方法/任务/指标/结论），不是模型凭常识补全的概念。
- **连得对**：关系类型、方向、适用条件与原文一致，不把共现、综述转述、推测当成直接证据。
- **对得齐**：别名、缩写、大小写、同名冲突被正确处理——**名字不是身份**，身份由样品/批次/条件一起决定。
- **查得到、回得去**：≥3 个真实查询，每个节点/边都能回到论文位置与原文片段。

本 Skill 是「脚本 + 规则 + 大模型复核」混合体：脚本做版面解析与**图谱校验**（证据真实性、关系受控词表、同名强制对齐决策），大模型负责实体关系抽取与语义判断。

## 2. 何时使用 / 何时不用

**使用**：任务要求从论文建知识图谱、抽实体关系、跨篇对齐、图谱查询。

**不用**：Nanopublication（阅读14，单条断言）、结构化笔记（阅读10）、翻译（阅读03）。

## 3. 输入与输出

**输入**：`/input/case.json`（`case_id` + `output_contract`）、`/input/task.md`、论文 PDF（可能一到多篇）。**以实际文件为准，不补造。**

**输出**：`/app/output/result.json`（`case_id` + 图谱 graph + 对齐决定 + 查询 + 校验报告 + DOT）。

## 4. 工作流程（按顺序）

### 第 0 步：读输入
记 `case_id` 与 `output_contract`；读 `task.md`；找到所有论文 PDF。

### 第 1 步：探测环境 + 解析（每篇都跑）
```bash
python3 -c "import pymupdf" 2>/dev/null && echo PY_PDF_ENGINE=1 || echo PY_PDF_ENGINE=0
```
- `=1` → 每篇 `python3 scripts/parse_pdf.py "<PDF>" --out /app/work/parse_<paper>.json`
- `=0` → 用 `pdf-text-tool`/`pdf-render-tool`/`ocr-tool` 兜底。

**按需取证** `--page N` / `--block p3.b7`；预算守恒，别把整篇/整表塞给模型。

### 第 2 步：抽实体与关系（draft.json）
```json
{
  "case_id": "…",
  "entities": [
    {"id": "e1", "name": "graphene oxide", "type": "material", "paper": "A",
     "mention": "GO", "evidence": {"quote": "…", "page": 2, "block_id": "p2.b3"}}
  ],
  "relations": [
    {"id": "r1", "subject": "e1", "object": "e2", "type": "uses",
     "conditions": "…", "evidence": {"quote": "…", "page": 3, "block_id": "p3.b1"}}
  ],
  "alignment": [
    {"entities": ["e1", "e5"], "decision": "merge", "reason": "同为 GO，均指氧化石墨烯"},
    {"entities": ["e2", "e6"], "decision": "keep_separate", "reason": "同名但一个是自制一个是购入"}
  ],
  "queries": [{"query": "哪些材料用了 FTIR？", "results": ["e1"], "evidence": ["r1"]}],
  "uncertainty": [], "change_log": []
}
```

**抽取规则**：
- 实体 `type` 用受控词表：`researcher`/`material`/`method`/`task`/`metric`/`conclusion`；每个实体带 `evidence`（原文片段 + page + block_id）与 `mention`（原文里的原词）。
- 关系 `type` 用 `uses`/`compares`/`outperforms`/`supports`/`contradicts`/`produces`/`measures`/`correlates_with`；`subject`/`object` 必须是已声明实体的 `id`；每个关系带 `evidence` 与 `conditions`（适用条件）。
- **同名必须显式决策**：两实体名字相同（或缩写冲突）时，`alignment` 里必须有一条 `merge`/`keep_separate`/`unresolved` 且带 `reason`。**不要凭名字自动合并**——样品、批次、实验条件不同就是不同实体。
- **实验条件别"搬家"**：某条件（如 24°C）只属于它所在的图/段落，不要挪到另一处。

### 第 3 步：脚本校验 + 导出
```bash
python3 scripts/kg.py build --parse /app/work/parse_A.json --draft /app/work/draft.json --out /app/output/result.json
```
脚本核验：实体/关系证据是否真在原文该位置、类型是否在词表、关系的 subject/object 是否指向已存在实体、同名实体是否有显式对齐决策、是否 ≥3 查询。**报错回第 2 步改。**

### 第 4 步：自查
output_contract 全覆盖？每个节点/边能回原文？同名冲突都显式决策了？查询有结果且带证据？

## 5. 异常与诚实规则

| 情况 | 处置 |
|-|-|
| 同名实体无法确定是否合并 | 决策写 `unresolved` + 说明，不要硬并 |
| 关系无直接证据（共现/转述/推测） | 不建边，或标 `evidence_strength: weak` 并写进 `uncertainty` |
| 查询无结果 | 如实写"该查询无结果"，不编节点 |
| 加密 PDF / 扫描件 | `cannot_judge` 或 OCR 兜底 |

**总原则**：论文是唯一事实依据；节点边可复核；无法判断的绝不写成事实。
