# 最小调用示例（示意，非正式案例结果）

```bash
python3 scripts/parse_pdf.py paper.pdf --out parse.json
python3 scripts/kg.py build --parse parse.json --draft draft.json --out result.json
```

示意 `draft.json`（节选，标注为 EXAMPLE）：

```json
{
  "case_id": "EXAMPLE",
  "entities": [
    {"id": "e1", "name": "graphene oxide", "type": "material", "paper": "A",
     "mention": "GO", "evidence": {"quote": "graphene oxide (GO) was prepared ...", "page": 2, "block_id": "p2.b3"}}
  ],
  "relations": [
    {"id": "r1", "subject": "e1", "object": "e2", "type": "uses",
     "conditions": "FTIR spectroscopy", "evidence": {"quote": "…", "page": 3, "block_id": "p3.b1"}}
  ],
  "alignment": [
    {"entities": ["e1", "e5"], "decision": "keep_separate",
     "reason": "same name GO but one self-made, one purchased"}
  ],
  "queries": [{"query": "哪些材料用了 FTIR？", "results": ["e1"], "evidence": ["r1"]}]
}
```

示意校验结论（节选，标注为 EXAMPLE）：

```json
{ "errors": [], "warnings": [ {"reason": "same_name_no_alignment", "name": "go", "ids": ["e1","e5"]} ] }
```

> 以上为示例。`same_name_no_alignment` 表示同名实体没有显式 merge/keep_separate 决策，需补一条 `alignment`。
