#!/usr/bin/env python3
"""Deterministic build/fix assistant for 写作13｜LaTeX 写作与编译.

The Agent edits .tex and compiles.  This script does the deterministic part a
weak model gets wrong: locate EVERY error (file + line + root cause) instead of
stopping at the first one, run static checks before compiling, and keep a
compile-fix loop that converges cross-references.

Commands:
  python3 latex.py compile --main main.tex --out work/ --rounds 3
  python3 latex.py inspect --log work/main.log
  python3 latex.py check  --tex main.tex [--bib refs.bib]
  python3 latex.py verify --log work/main.log

It never edits the .tex itself — it reports, the model fixes, and re-runs.
"""
import argparse
import glob
import json
import os
import re
import subprocess
import sys

ENGINES = ["xelatex", "pdflatex", "lualatex", "latex"]


# ----------------------------------------------------------------------------
# static .tex checks
# ----------------------------------------------------------------------------
def strip_comments(s):
    """Remove TeX comments, keeping % not acting as a comment."""
    out = []
    for ln in s.split("\n"):
        # a % starts a comment unless preceded by an odd number of backslashes
        pct = -1
        bs = 0
        for i, ch in enumerate(ln):
            if ch == "\\":
                bs += 1
            else:
                if ch == "%" and bs % 2 == 0:
                    pct = i
                    break
                bs = 0
        out.append(ln[:pct] if pct >= 0 else ln)
    return "\n".join(out)


def _balanced(code, op, cl):
    """Return list of unmatched positions for a pair, ignoring escaped."""
    stack = []
    errs = []
    i = 0
    while i < len(code):
        if code[i] == "\\" and i + 1 < len(code):
            i += 2
            continue
        if code[i] == op:
            stack.append(i)
        elif code[i] == cl:
            if not stack:
                errs.append((i, f"unmatched {cl}"))
            else:
                stack.pop()
        i += 1
    for pos in stack:
        errs.append((pos, f"unmatched {op}"))
    return errs


def check_tex(path, bib_path=None):
    src = open(path, encoding="utf-8", errors="replace").read()
    code = strip_comments(src)
    report = {"errors": [], "warnings": [], "labels": {}, "commands": {}}

    # brace balance
    for pos, msg in _balanced(code, "{", "}"):
        report["errors"].append({"type": "brace", "detail": msg, "pos": pos})

    # environment balance
    begins = re.findall(r"\\begin\{([^}]+)\}", code)
    ends = re.findall(r"\\end\{([^}]+)\}", code)
    from collections import Counter
    bc, ec = Counter(begins), Counter(ends)
    for env, n in (bc - ec).items():
        report["errors"].append({"type": "environment", "detail": f"\\begin{{{env}}} without \\end", "env": env})
    for env, n in (ec - bc).items():
        report["errors"].append({"type": "environment", "detail": f"\\end{{{env}}} without \\begin", "env": env})

    # math mode balance: $ (unescaped), $$, \( \), \[ \]
    dollars = [m.start() for m in re.finditer(r"(?<!\\)\$", code)]
    if len(dollars) % 2 != 0:
        report["errors"].append({"type": "math", "detail": f"odd number of unescaped $ ({len(dollars)})"})
    for op, cl in [("\\(", "\\)"), ("\\[", "\\]")]:
        if code.count(op) != code.count(cl):
            report["errors"].append({"type": "math",
                                     "detail": f"{op} / {cl} unbalanced"})

    # labels vs refs
    for m in re.finditer(r"\\label\{([^}]+)\}", code):
        lab = m.group(1)
        if lab in report["labels"]:
            report["errors"].append({"type": "label", "detail": f"duplicate label {lab}"})
        report["labels"][lab] = m.start()
    refs = re.findall(r"\\(?:ref|eqref|pageref|autoref|cref)\{([^}]+)\}", code)
    for r in set(refs):
        if r not in report["labels"]:
            report["warnings"].append({"type": "ref", "detail": f"\\ref to undefined label {r}"})

    # cite targets (if bib given)
    if bib_path and os.path.exists(bib_path):
        bib = open(bib_path, encoding="utf-8", errors="replace").read()
        keys = set(re.findall(r"@\w+\s*\{([^,]+),", bib))
        cites = set(re.findall(r"\\cite[a-z]*\{([^}]+)\}", code))
        for c in cites:
            for k in [x.strip() for x in c.split(",")]:
                if k and k not in keys:
                    report["warnings"].append({"type": "cite", "detail": f"\\cite to undefined key {k}"})
    # \cite without a bibliography source (bibtex will report "no \\bibdata")
    if re.search(r"\\cite", code) and not re.search(r"\\bibliography\{", code) \
            and not re.search(r"\\begin\{thebibliography\}", code):
        report["warnings"].append({"type": "cite",
                                   "detail": "\\cite used but no \\bibliography{...} or thebibliography"})

    # undefined commands (a cheap pre-compile heuristic)
    defined = set(re.findall(r"\\(?:newcommand|renewcommand|def|DeclareMathOperator)\*?\{?\\([A-Za-z]+)", code))
    defined |= {"documentclass", "begin", "end", "usepackage", "cite", "ref", "eqref",
                "pageref", "label", "section", "subsection", "subsubsection", "paragraph",
                "caption", "includegraphics", "frac", "sqrt", "sum", "int", "prod", "lim",
                "alpha", "beta", "gamma", "delta", "epsilon", "theta", "lambda", "mu",
                "pi", "sigma", "phi", "omega", "times", "cdot", "pm", "leq", "geq",
                "neq", "approx", "infty", "partial", "nabla", "left", "right", "text",
                "textbf", "textit", "mathrm", "mathbf", "emph", "item", "tableofcontents",
                "maketitle", "author", "title", "date", "footnote", "thanks", "newline",
                "hline", "multicolumn", "multirow", "toprule", "midrule", "bottomrule",
                "centering", "raggedright", "footnotesize", "small", "large", "Large",
                "underline", "overline", "hat", "tilde", "bar", "vec", "dot", "ddot",
                "quad", "qquad", "nonumber", "displaystyle", "operatorname", "substack",
                "min", "max", "log", "exp", "sin", "cos", "tan", "deg", "circ",
                "mathbb", "mathcal", "mathscr", "operatorname", "textnormal", "si",
                "SI", "num", "unit", "ang", "LaTeX", "TeX"}
    for m in re.finditer(r"\\([A-Za-z]+)", code):
        cmd = m.group(1)
        if cmd not in defined and cmd not in report["commands"]:
            report["commands"][cmd] = 0
        if cmd in report["commands"]:
            report["commands"][cmd] += 1
    unknown = {c: n for c, n in report["commands"].items() if c not in defined}
    for c, n in sorted(unknown.items(), key=lambda kv: -kv[1])[:10]:
        report["warnings"].append({"type": "command", "detail": f"possibly undefined \\{c} (x{n})"})
    del report["commands"]

    return report


# ----------------------------------------------------------------------------
# log parsing
# ----------------------------------------------------------------------------
_ERROR_SIGS = ("Missing", "Undefined control", "LaTeX Error", "Extra", "Double",
               "Misplaced", "Runaway", "Emergency stop", "Too many", "Illegal",
               "You can't", "Argument of", "Paragraph ended", "Display math",
               "Bad math", "Improper", "Not in outer", "TeX capacity",
               "File ended", "Dimension too large", "Number too big",
               "Arithmetic overflow", "Missing \\", "No \\title", "No \\author",
               "Undefined", "\\begin{", "\\end{", "Environment")


def _is_error_msg(msg):
    if "Warning" in msg or "Overfull" in msg or "Underfull" in msg:
        return False
    return msg.startswith(_ERROR_SIGS)


def parse_log(text):
    errors, warnings = [], []
    refs, cites = set(), set()
    lines = text.split("\n")
    for i, ln in enumerate(lines):
        # classic `!` error line
        if ln.startswith("!"):
            msg = ln[1:].strip()
            line_no, context = None, ""
            for j in range(i + 1, min(i + 8, len(lines))):
                nxt = lines[j]
                m = re.match(r"^l\.(\d+)\s*(.*)$", nxt)
                if m:
                    line_no = int(m.group(1))
                    context = m.group(2).strip()
                    break
            errors.append(_classify(msg, line_no, context))
            continue
        # -file-line-error format: path/file.tex:NN: message
        m = re.match(r"^(?:\./)?(.+?\.(?:tex|sty|cls|bib|cfg|def)):(\d+):\s*(.+)$", ln)
        if m and _is_error_msg(m.group(3)):
            errors.append(_classify(m.group(3).strip(), int(m.group(2)), ""))
            continue
        # warnings (search within line, so the file:line: prefix is tolerated)
        m = re.search(r"LaTeX Warning: Reference `([^']+)' .*?undefined", ln)
        if m:
            refs.add(m.group(1))
            warnings.append({"kind": "undefined_reference", "target": m.group(1),
                             "line": _line_no(ln), "message": ln.strip()})
        m = re.search(r"LaTeX Warning: Citation `([^']+)' .*?undefined", ln)
        if m:
            cites.add(m.group(1))
            warnings.append({"kind": "undefined_citation", "target": m.group(1),
                             "line": _line_no(ln), "message": ln.strip()})
        m = re.search(r"Package (\w+) Warning: (.*)", ln)
        if m and "undefined" not in ln.lower():
            warnings.append({"kind": "package_warning", "package": m.group(1),
                             "message": m.group(2).strip()})
    return {"errors": errors, "warnings": warnings,
            "undefined_refs": sorted(refs), "undefined_cites": sorted(cites)}


def _line_no(ln):
    m = re.search(r"on input line (\d+)", ln)
    return int(m.group(1)) if m else None


def _classify(msg, line, ctx):
    kind = "unknown"
    if "Undefined control sequence" in msg:
        kind = "undefined_control_sequence"
        if ctx:
            m = re.search(r"\\([A-Za-z]+)", ctx)
            if m:
                msg = f"Undefined control sequence \\{m.group(1)}"
    elif "Missing $" in msg:
        kind = "missing_dollar"
    elif "File" in msg and "not found" in msg:
        kind = "missing_file"
    elif "Environment" in msg and ("undefined" in msg or "ended by" in msg):
        kind = "environment_mismatch"
    elif "Missing \\endcsname" in msg:
        kind = "missing_endcsname"
    elif "Extra }" in msg or "Missing }" in msg:
        kind = "brace_mismatch"
    elif "Double superscript" in msg:
        kind = "double_superscript"
    elif "Misplaced alignment tab" in msg or "Misplaced &" in msg:
        kind = "misplaced_alignment"
    elif "Undefined control" in msg:
        kind = "undefined_control_sequence"
    return {"kind": kind, "message": msg, "line": line, "context": ctx}


# ----------------------------------------------------------------------------
# compile + verify
# ----------------------------------------------------------------------------
def find_engine():
    for e in ENGINES:
        p = subprocess.run(["which", e], capture_output=True, text=True)
        if p.returncode == 0:
            return p.stdout.strip()
    return None


def compile_tex(args):
    engine = find_engine()
    out_dir = args.out or os.path.dirname(os.path.abspath(args.main)) or "."
    os.makedirs(out_dir, exist_ok=True)
    main_abs = os.path.abspath(args.main)
    report = {"engine": engine or "latex-compiler-tool", "rounds": [], "success": False}

    if not engine:
        report["errors"] = [{"kind": "no_engine",
                             "detail": "no TeX binary; use the latex-compiler tool, "
                                       "then run `inspect` on the produced .log"}]
        return report

    jobname = os.path.splitext(os.path.basename(args.main))[0]
    src_dir = os.path.dirname(main_abs) or "."
    bib_available = bool(glob.glob(os.path.join(src_dir, "*.bib"))) or \
        bool(glob.glob(os.path.join(src_dir, "**", "*.bib"), recursive=True))
    bibtex_ran = False
    prev_refs, prev_cites = None, None

    def run_engine():
        # nonstopmode WITHOUT -halt-on-error: collect ALL errors in one pass,
        # not just the first (the rubric's "不要停在第一条错误信息")
        p = subprocess.run(
            [engine, "-interaction=nonstopmode", "-file-line-error",
             f"-output-directory={out_dir}", main_abs],
            capture_output=True, text=True, cwd=src_dir, timeout=180)
        log_path = os.path.join(out_dir, jobname + ".log")
        log_text = ""
        if os.path.exists(log_path):
            log_text = open(log_path, encoding="utf-8", errors="replace").read()
        parsed = parse_log(log_text)
        parsed["exit_code"] = p.returncode
        parsed["pdf_exists"] = os.path.exists(os.path.join(out_dir, jobname + ".pdf"))
        return parsed

    def run_bibtex():
        env = dict(os.environ)
        env["BIBINPUTS"] = src_dir + ":" + env.get("BIBINPUTS", "")
        p = subprocess.run(["bibtex", jobname], capture_output=True, text=True,
                           cwd=out_dir, env=env, timeout=120)
        return p.returncode == 0

    for rnd in range(1, args.rounds + 1):
        parsed = run_engine()
        # bibtex between first and second pass so \cite resolves
        if rnd == 1 and bib_available and parsed.get("undefined_cites"):
            bibtex_ran = run_bibtex()
        report["rounds"].append(parsed)
        fatal = [e for e in parsed["errors"]
                 if e["kind"] in ("undefined_control_sequence", "missing_dollar",
                                  "missing_file", "environment_mismatch",
                                  "missing_endcsname", "brace_mismatch",
                                  "double_superscript", "misplaced_alignment")]
        refs = set(parsed.get("undefined_refs", []))
        cites = set(parsed.get("undefined_cites", []))
        if parsed["exit_code"] == 0 and not fatal:
            if not refs and not cites:
                report["success"] = True
                break
            # unresolved refs/cites that no longer change: stop, but NOT success
            if prev_refs is not None and refs == prev_refs and cites == prev_cites:
                break
        prev_refs, prev_cites = refs, cites

    last = report["rounds"][-1]
    report["bibtex_ran"] = bibtex_ran
    report["summary"] = {
        "success": report["success"],
        "rounds_used": len(report["rounds"]),
        "last_error_count": len(last["errors"]),
        "undefined_refs": last.get("undefined_refs", []),
        "undefined_cites": last.get("undefined_cites", []),
    }
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return report


def inspect(args):
    text = open(args.log, encoding="utf-8", errors="replace").read()
    print(json.dumps(parse_log(text), ensure_ascii=False, indent=2))
    return 0


def verify(args):
    text = open(args.log, encoding="utf-8", errors="replace").read()
    parsed = parse_log(text)
    success = "Output written on" in text and not parsed["errors"]
    print(json.dumps({"success": success, "errors": parsed["errors"],
                      "undefined_refs": parsed["undefined_refs"],
                      "undefined_cites": parsed["undefined_cites"]},
                     ensure_ascii=False, indent=2))
    return 0


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__)
    sub = ap.add_subparsers(dest="cmd", required=True)
    c = sub.add_parser("compile")
    c.add_argument("--main", required=True)
    c.add_argument("--out")
    c.add_argument("--rounds", type=int, default=3)
    i = sub.add_parser("inspect")
    i.add_argument("--log", required=True)
    v = sub.add_parser("verify")
    v.add_argument("--log", required=True)
    k = sub.add_parser("check")
    k.add_argument("--tex", required=True)
    k.add_argument("--bib")
    args = ap.parse_args(argv)
    if args.cmd == "compile":
        compile_tex(args)
        return 0
    if args.cmd == "inspect":
        return inspect(args)
    if args.cmd == "verify":
        return verify(args)
    if args.cmd == "check":
        print(json.dumps(check_tex(args.tex, args.bib), ensure_ascii=False, indent=2))
        return 0
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
